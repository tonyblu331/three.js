# LightProbeGridGPU compute projection runtime parity handoff

Generated: 2026-05-28T01:50:21+07:00
Workspace: G:/Antonio Bonet/three.js
Branch observed: $(git branch --show-current)

## Current result

The compute projection root cause is fixed and the runtime parity gate now passes in browser/WebGPU.

`json
{   "status": "RUNTIME-PARITY-READBACK-PASSING",   "computeFallbackReason": null,   "coefficientMaxDelta": 0,   "atlasMaxDelta": 0,   "coefficientTolerance": 0.035,   "atlasTolerance": 0.035,   "coefficientPass": true,   "atlasPass": true,   "tolerancePass": true,   "coefficientReadbackPixels": 72,   "totalProbes": 8,   "statusCurrent": "IMPLEMENTED-WITH-PARITY-EVIDENCE" }
`

## Judgment Day result

Two blind judges agreed on the same CRITICAL root cause:

- xamples/jsm/lighting/LightProbeGridGPU.js samples the cubemap in the compute projection node with cubeTexture( this.cubeRenderTarget.texture, coord, 0 ).
- src/nodes/accessors/CubeTextureNode.js previously always applied materialEnvRotation in setupUV().
- materialEnvRotation updates through scene/material environment state, but enderer.compute()/NodeManager.updateForCompute() runs with no render-object scene/material context.
- That caused Cannot read properties of null (reading 'environment') and forced OPEN-RUNTIME-COMPUTE-FALLBACK.

## Root-cause fix

CubeTextureNode.setupUV() now skips material environment rotation when uilder.shaderStage === 'compute'.

This keeps explicit compute cubemap sampling from pulling scene/material environment uniforms while preserving:

- fragment-path environment rotation;
- WebGPU cubemap coordinate flipping;
- fragment fallback for unsupported/failed compute projection;
- public API compatibility.

Because builds are forbidden, the local e2e build artifact used by the example was patched directly as well:

- src/nodes/accessors/CubeTextureNode.js
- uild/three.webgpu.js

## Evidence gates now enforced

- 	est/e2e/lightprobegrid-gpu-runner-core-assertions.js rejects the old null-environment fallback reason.
- 	est/e2e/lightprobegrid-gpu-artifacts.js now requires RUNTIME-PARITY-READBACK-PASSING with compute backend, no fallback reason, coefficient pass, atlas pass, and tolerance pass.
- 	est/e2e/lightprobegrid-gpu-source-invariants.js requires the compute-stage cubemap guard in both source and local build output.
- 	est/e2e/lightprobegrid-gpu-proof-research-sections.js marks runtime backlog tasks as backed by runtime parity evidence when the readback gate passes.

## Verification run

No build was run.

`	xt
node --check src/nodes/accessors/CubeTextureNode.js
node --check build/three.webgpu.js
node --check test/e2e/lightprobegrid-gpu-runner-core-assertions.js
node --check test/e2e/lightprobegrid-gpu-source-invariants.js
node --check test/e2e/lightprobegrid-gpu-artifacts.js
node --check test/e2e/lightprobegrid-gpu-proof-research-sections.js
node test/e2e/lightprobegrid-gpu-source-invariants.js
PUPPETEER_EXECUTABLE_PATH="C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe" node test/e2e/puppeteer.js --webgpu webgpu_lightprobes_cornell
node test/e2e/lightprobegrid-gpu-artifacts.js
`

Result:

`	xt
Smoke 34 checks in file: webgpu_lightprobes_cornell
TEST PASSED! 1 screenshots rendered correctly.
compute projection status: RUNTIME-PARITY-READBACK-PASSING
coefficientMaxDelta: 0 / 0.035
atlasMaxDelta: 0 / 0.035
coefficientPass: true
atlasPass: true
tolerancePass: true
`

## Screenshots/artifacts

Included from C:/Users/tonyb/AppData/Local/Temp/codex-threejs-lightprobes-parity:

- screenshots/low-res-validity-weighted.png
- screenshots/low-res-damped.png
- screenshots/low-res-unweighted.png
- screenshots/webgpu-webgl-density-reference.png
- screenshots/webgpu-webgl-density-damped.png
- screenshots/webgpu-webgl-density-shadow-crisp.png
- screenshots/webgpu-webgl-density-shadowless.png
- screenshots/webgl-lightprobegrid-reference.png
- proof-report.json
- proof-table.md

## Boundary that still matters

This is not permission to remove fallback. The legal state is internal compute-probe-reduction behind guards with browser readback parity evidence, while ragment-coefficient-projection remains the fallback.
