# LightProbeGridGPU DDGI-lite proof-only causal attribution handoff

Generated: 2026-05-27T13:19:06.101Z
Workspace: `G:/Antonio Bonet/three.js`
Branch observed: `codex/runtime-lightprobe`

## Goal prompt / operating constraints

Goal: continue proof-only causal attribution for the LightProbeGridGPU DDGI-lite leak until the dominant cause, next steps, uncertainties, and screenshot evidence are clear.

Hard constraints followed:
- Do **not** build.
- Do **not** tune Chebyshev.
- Do **not** add runtime/public API/docs/bake-policy/source-policy behavior.
- Do **not** promote runtime SDF/blocker work.
- Keep work in proof/report artifacts until causal attribution is bounded.

## Current result, short version

```txt
Design-bound status: SUPPORTED-PROOF-ONLY-PROBE50-L10Z-DESIGN-BOUND-CONSTRAINTS
Aggregate residual guard: SUPPORTED-PROBE50-LOCAL-CORRECTION-AGGREGATE-RESIDUAL-GUARD
Local correction oracle: SUPPORTED-PROBE50-COEFFICIENT-LOCAL-CORRECTION-ORACLE-WIN
Identified target: probe 50 / L10/l1 / z
Aggregate wrong pressure before: 0.02
Aggregate estimated wrong pressure after: 0.0008
Aggregate reduction ratio: 0.96
Unmapped probe-52 residual wrong pressure: 0.0007
Unmapped residual correct preservation: 0.0393
Runtime promotion allowed: false
```

## Screenshots

Current proof screenshot:

![Current proof screenshot](screenshots/low-res-validity-weighted.png)

WebGL/reference comparison captures included in this zip:

- `screenshots/webgl-lightprobegrid-reference.png` — WebGL LightProbeGrid reference artifact.
- `screenshots/webgpu-webgl-density-reference.png` — WebGPU/WebGL density reference artifact.

## WebGPU proof vs WebGL baseline read

This package does not claim photometric parity. The comparison is evidence-oriented: WebGPU proof artifacts demonstrate the current DDGI-lite probe behavior under the verifier; WebGL artifacts are baseline/reference captures for visual sanity and historical comparison. The current causal finding is coefficient-level, not a renderer-wide WebGPU-vs-WebGL regression claim.

Key distinction:
- WebGL baseline: reference/sanity image path.
- WebGPU proof: instrumented proof path with receiver/probe/SH attribution and leak-pressure studies.
- Current leak cause: localized SH coefficient polarity/content issue around `probe-50 / L10 / z`, not a broad WebGPU renderer mismatch.

## Method / process

1. Preserved proof/runtime separation. Runtime-facing changes stayed blocked.
2. Split mapped vs unmapped leak rows instead of forcing one explanation.
3. Compared aggregate hypotheses: bake-content coverage vs coefficient-level L10 coverage.
4. Followed dominant pressure: probe-50/rightReceiver L10/l1 accounted for almost all wrong-channel pressure.
5. Rejected source-policy/bake-policy/global damping when evidence contradicted those abstractions.
6. Isolated basis/polarity: L10 z-basis negative-correct polarity created positive wrong-minus-correct.
7. Estimated a proof-only coefficient-local correction and guarded aggregate residuals.
8. Added design-bound constraints before any runtime sketch or implementation.

## Study stack / sixteen-study context

The full proof report contains many studies; this handoff focuses on the causal chain that mattered in this continuation. Relevant current studies:

| Study | Status | Why it matters |
|---|---|---|
| `proof7cDispositionStudy` | `CLOSED-PROOF-7C-DISPOSITION-NO-RUNTIME-PROMOTION` | Report-only proof-7c disposition after CPU/static-blocker oracle evaluation; documents whether proof-7c is addressed and whether runtime SDF/blocker promotion is allowed, without changing runtime, public API, bake policy, docs, or Chebyshev thresholds. |
| `mappedBakeContentSourcePolicyOracleStudy` | `OPEN-MAPPED-BAKE-CONTENT-SOURCE-POLICY-ORACLE` | Mapped rows carry bake-content pressure, but content band and runtime attribution band disagree while the dominant runtime coefficient is L10; a source-policy oracle must report coefficient-level effects instead of assuming a simple bake-L2 fix. |
| `unmappedCoefficientAttributionInstrumentationStudy` | `OPEN-UNMAPPED-COEFFICIENT-ATTRIBUTION-INSTRUMENTATION` | Unmapped rows leak through L10 coefficient attribution while bake-content pressure attribution remains empty, so they are not explained by the mapped bake-content/source-policy bucket. |
| `aggregateExplanationComparisonStudy` | `OPEN-AGGREGATE-L10-COEFFICIENT-EXPLANATION` | The aggregate common denominator is L10/l1 coefficient attribution across both mapped and unmapped buckets; bake-content/source-policy evidence covers only the mapped subset, so runtime and bake-policy promotion remain blocked. |
| `proof7bCoefficientL10OracleStudy` | `IDENTIFIED-PROOF-7B-L10-PROBE50-DOMINANT-RESIDUAL-BOUNDED` | Probe-50/rightReceiver L10/l1 is the dominant wrong-channel pressure source; probe-52/leftReceiver is a low-pressure residual trace, so global L10 damping is not a safe runtime conclusion. |
| `probe50L10SignSourceIsolationOracleStudy` | `IDENTIFIED-PROBE50-L10-POSITIVE-SOURCE-LOCALIZED` | Probe-50 L10/l1 leak is positive wrong-minus-correct, mapped to bake-content pressure, and localized to a correct-side source trace; this identifies a probe-local coefficient/content polarity problem, not a wrong-side source-policy or global L10 damping fix. |
| `probe50L10ContentBasisPolarityOracleStudy` | `IDENTIFIED-PROBE50-L10-Z-BASIS-NEGATIVE-CORRECT-POLARITY` | Probe-50 L10/l1 is a z-basis polarity leak: the correct green channel is driven more negative than the wrong red channel, making wrong-minus-correct positive while L00 and L11 remain corrective. |
| `probe50CoefficientLocalCorrectionOracleStudy` | `SUPPORTED-PROBE50-COEFFICIENT-LOCAL-CORRECTION-ORACLE-WIN` | A coefficient-local probe-50/L10/z correction explains the dominant wrong-channel pressure while preserving L00/L11 corrective rows; the remaining work is design-bounding, not runtime promotion. |
| `probe50LocalCorrectionAggregateResidualGuardStudy` | `SUPPORTED-PROBE50-LOCAL-CORRECTION-AGGREGATE-RESIDUAL-GUARD` | The probe-50/L10/z local-correction candidate removes the aggregate-dominant mapped wrong-channel pressure, leaving only a bounded probe-52 unmapped residual whose correct-channel preservation dominates its wrong pressure. |
| `probe50L10ZDesignBoundConstraintsStudy` | `SUPPORTED-PROOF-ONLY-PROBE50-L10Z-DESIGN-BOUND-CONSTRAINTS` | The proof-only design bounds identify a narrow probe-50/L10/z correction shape and reject global L1 damping, source-policy changes, bake-policy changes, Chebyshev tuning, and public API/docs promotion for this phase. |

## Findings

### 1. Not a simple SDF/blocker fix
`proof-7c` is closed with no runtime promotion. The static blocker path did not justify runtime SDF/blocker work.

### 2. Not a source-policy or bake-policy fix
Mapped rows show bake/content pressure, but runtime attribution lands on `L10/l1`; dominant rows are correct-side sourced. That means blindly changing bake/source policy would be architecture cargo cult.

### 3. Dominant cause is coefficient-local
Probe-50/rightReceiver L10/l1 dominates pressure. Wrong pressure share: 0.965.

### 4. The polarity issue is narrow
Basis: z. L10 wrong-minus-correct sum: 0.5973. Weighted: 0.0192. L00 and L11 remain corrective, so broad L1 damping is unsafe.

### 5. Aggregate residual guard supports the local abstraction
Aggregate wrong pressure drops from 0.02 to 0.0008. The residual is bounded and probe-52 correct preservation dominates wrong pressure by 56.1429x.

## Bugs / contract weaknesses found and fixed

- Contract bug: local correction initially expected exact zero after correction; real rounded residual was bounded at `0.0001`. Fixed the contract to use bounded residual `<= 0.001`.
- Proof-report weakness: mapped/unmapped follow-ups needed explicit studies, not prose. Added executable studies and validation.
- Branch-routing weakness: proof-7c needed explicit closure/no-runtime-promotion disposition.
- Validation weakness: proof-only next actions must explicitly say `proof-only`; report contracts enforce this.

## Design sketch / theory

The only supported future correction shape is intentionally narrow:

```txt
candidate shape: probe-local coefficient-local correction
scope:           probe 50 only
coefficient:     L10 / l1
basis:           z
must preserve:   L00, L11, all non-target coefficient rows
must bound:      aggregate residual <= 0.001 in proof artifact
must reject:     global L1 damping, source policy, bake policy, Chebyshev tuning
```

Theory: the leak is caused by a local SH coefficient polarity/content imbalance where the correct green channel is driven more negative than the wrong red channel for the L10/z contribution, causing positive wrong-minus-correct pressure even though other coefficients remain corrective.

## Uncertainties / what is not proven

- This is not yet a runtime implementation.
- This is not a public API or docs-ready feature.
- This is not a Chebyshev-tuning result.
- This does not prove renderer-wide WebGPU/WebGL parity.
- The correction sketch still needs proof-only implementation-sketch review before touching runtime code.
- Need to ensure any eventual runtime shape generalizes beyond this Cornell proof fixture without overfitting probe 50.

## Validation logs

```txt
node --check touched files: PASS
source invariants: PASS
git diff --check: PASS (existing LF->CRLF warnings in docs/pages/LightProbeGrid.html.md and test/e2e/puppeteer.js)
Judgment self-review: PASS
Fresh WebGPU proof: PASS
Smoke 33 checks in file: webgpu_lightprobes_cornell
TEST PASSED! 1 screenshots rendered correctly.
Known cleanup noise: ERROR: no se encontró el proceso "..." after browser close; not a proof failure.
```

## Next steps

1. Prepare a proof-only implementation-sketch review for the probe-50/L10/z constraint shape.
2. Keep runtime/API/docs/bake/source-policy/Chebyshev blocked until sketch review and human architecture approval.
3. If sketch is approved, create a minimal runtime design proposal with explicit gates and rollback criteria — still do not silently promote.
4. Re-run full proof and compare against WebGL/reference captures after any future runtime candidate.

## Included files

- `proof-report.json` — fresh machine-readable proof report.
- `proof-table.md` — fresh proof table artifact.
- `screenshots/low-res-validity-weighted.png` — current proof screenshot.
- `screenshots/webgl-lightprobegrid-reference.png` — WebGL reference artifact.
- `screenshots/webgpu-webgl-density-reference.png` — WebGPU/WebGL density reference artifact.
- `related-files/...` — only proof/report source files touched by this phase, no broad repo bloat.

---

# 2026-05-28 Runtime Compute Projection Evidence Update

This rezip includes the new guarded runtime compute projection evidence gate requested after the original proof-only handoff.

## Added gates

- `compute coefficients vs fragment coefficients`
- `atlas repack parity`
- `tolerance validation`

## Actual browser/WebGPU result

```txt
status: OPEN-RUNTIME-COMPUTE-FALLBACK
baselinePath: fragment-coefficient-projection
candidatePath: compute-probe-reduction
fragmentBackend: fragment-coefficient-projection
computeBackend: fragment-coefficient-projection
computeFallbackReason: Cannot read properties of null (reading 'environment')
coefficientTolerance: 0.035
atlasTolerance: 0.035
coefficientPass: false
atlasPass: false
tolerancePass: false
contractState: IMPLEMENTED-GUARDED-PENDING-RUNTIME-PARITY
```

## Interpretation

The gates are now executable and captured in the proof report, but the compute backend did **not** reach coefficient/atlas parity in this environment because the guarded compute path fell back before readback. This means full promotion to `IMPLEMENTED-WITH-PARITY-EVIDENCE` is still blocked. Fragment projection remains the correct fallback.

## New artifact locations inside this zip

- `artifacts/proof-report.json` — full proof report with `computeProjectionRuntimeParityEvidence`.
- `artifacts/proof-table.md` — markdown proof table with runtime readback parity section.
- `artifacts/*.png` — refreshed screenshots from the 2026-05-28 e2e run.
