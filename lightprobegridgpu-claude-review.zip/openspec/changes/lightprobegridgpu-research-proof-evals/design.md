# Design: LightProbeGridGPU Research-Proof Evals

## Technical Approach

Keep the existing smoke harness shape, but sharpen ownership: harness modules capture raw evidence, runner assertions validate evidence shape, proof gates derive verdicts, and artifacts serialize compact summaries.

## Architecture Decisions

| Decision | Choice | Rejected | Rationale |
|----------|--------|----------|-----------|
| Verdict ownership | `test/e2e/lightprobegrid-gpu-proof-gates.js` derives proof verdicts | Status prose scattered in harness diagnostics | Freezes falsifiable gates and prevents narrative proof drift. |
| Evidence capture | Keep proof-only readback in harness/diagnostics modules | Runtime readback or public API hooks | Preserves GPU-resident runtime boundary. |
| Abstraction style | Local helpers only when they delete repeated lifecycle/payload logic | Thin pass-through modules | KISS/YAGNI; ownership matters more than file count. |
| Verification | No-build checks only | `npm run build` | Matches current refactor stream constraints. |
| Baseline framing | Treat scalar/WebGL and old LightProbeVolume work as comparators/problem statements | Treating the baseline as ground truth | Upstream discussion already shows missing per-object/material probe volume support; this patch must be honest about bounded improvement and remaining gaps. |
| Post-rejection direction | Prefer classification/relocation or a stronger visibility representation | Retrying adjacent-cross fallback or threshold tuning | Focused evals show adjacent hits exist, but borrowing neighboring bins does not close the gate without regressions. |

## Data Flow

```text
LightProbeGridGPUTestHarness / diagnostics
  -> raw compact facts
  -> runner assertions validate shape
  -> proof-gates derive SUPPORTED/OPEN
  -> artifacts write compact proof-summary.json
```

## File Changes

| File | Action | Description |
|------|--------|-------------|
| `examples/jsm/lighting/LightProbeGridGPUTestHarness.js` | Modify | Remove unconsumed payload and consolidate repeated proof lifecycle where it truly deletes concepts. |
| `examples/jsm/lighting/LightProbeGridGPUVisibilityWeightingStudy.js` | Modify | Keep only receiver evidence consumed by visibility/SH/surface diagnostics and gates. |
| `test/e2e/lightprobegrid-gpu-proof-gates.js` | Modify | Centralize verdict thresholds and rejection reasons. |
| `test/e2e/lightprobegrid-gpu-runner-*.js` | Modify | Assert compact raw fact contracts. |
| `lightprobegrid-gpu-refactor-plan.md` | Modify | Keep roadmap current and short. |

## Interfaces / Contracts

Raw fact objects SHOULD include measured values and availability flags. Gate objects include `id`, `subject`, `metric`, `actual`, `expected`, `status`, `reason`, and optional `evidenceRef`.

## Testing Strategy

| Layer | What to Test | Approach |
|-------|--------------|----------|
| Syntax | touched JS files parse | `node --check` |
| Boundary | runtime remains GPU-resident | `checkSmokeSourceInvariants(...)` |
| Diff hygiene | no whitespace/errors | `git diff --check` |

## Migration / Rollout

No migration required.

## Open Questions

- [ ] Which remaining harness `status` fields are raw availability evidence versus verdicts that belong in proof gates?

## Adjacent Visibility-Moment Rescue SDD

### Planning Metaprompt

Use this prompt when implementing or reviewing the adjacent visibility-moment rescue:

```text
Plan or evaluate a focused LightProbeGridGPU SDD slice for `visibilityWeighting.noWrongSideEscape`.

Current evidence says the four wrong-side escapes are 8px octahedral exact-bin no-hit misses with adjacent-bin hit coverage, not receiver/probe direction mismatch, culling/side capture, fixture geometry bypass, high Chebyshev visibility, or SH mixed-color risk.

North star: prove whether a bounded GPU-resident adjacent visibility-moment lookup can eliminate those four exact-bin no-hit escapes without regressing directional suppression, correct bounce, compact proof ownership, runtime GPU residency, or residual-leak honesty.

Require explicit goal, ideal state, non-goals, runtime candidate, proof-gate evidence requirements, cost ceilings, over-occlusion rejection criteria, focused verification, and acceptance/rejection outcomes.

Prefer conditional cross-bin fallback: exact bin first; only if hitConfidence is zero, sample cross-adjacent bins; choose the adjacent hit with the lowest computed Chebyshev visibility; preserve no-hit behavior when no adjacent hit exists. Do not tune thresholds, treat scalar/WebGL as truth, add CPU readback to runtime, or soften the residual leak gate.
```

### Goal

Determine whether a bounded GPU-resident adjacent visibility-moment lookup can eliminate the four `visibilityWeighting.noWrongSideEscape` exact-bin no-hit escapes without regressing directional suppression, correct bounce, compact proof ownership, runtime GPU residency, or residual-leak honesty.

### Current Evidence

The current focused Cornell proof classifies the four open wrong-side escapes as:

- `visibilityDepthResolution = 8`
- `wrongSideEscapedCount = 4`
- `weakCrushNoHitEscapeCount = 4`
- `weakCrushNoHitCrossingCount = 4`
- `weakCrushNoHitVisibilitySegmentHitCount = 4`
- `weakCrushNoHitSurfaceSegmentHitCount = 4`
- `weakCrushNoHitReceiverProbeDirectionMismatchCount = 0`
- `weakCrushNoHitAdjacentHitCount = 4`
- `weakCrushNoHitAllAdjacentNoHitCount = 0`
- `weakCrushNoHitDistinctOctBinCount = 4`

That evidence rules out fixture geometry bypass, culling/side capture, receiver/probe direction mismatch, and total visibility-bake absence for this gate. The remaining failure is an exact 8px octahedral bin miss where adjacent bins have hit coverage.

### Ideal State

The ideal state is a supported `visibilityWeighting.noWrongSideEscape` gate with:

- `wrongSideEscapedCount = 0`;
- the four current exact-bin misses rescued by a bounded adjacent lookup;
- `visibilityWeighting.directionalSuppression` still supported;
- SH mixed-color risk and correct-bounce gates still supported;
- residual leak still reported independently against the sealed-wall zero-leak oracle;
- no CPU readback or proof helper added to runtime;
- compact proof facts that explain fallback activity without row dumps or per-probe arrays.

### Non-Goals

- Do not close `sealedWall.preToneMaskedWrongSideResidualLeakRatio` by comparison to the scalar/WebGL baseline.
- Do not tune thresholds to make gates green.
- Do not expand visibility diagnostics with rows, arrays, narrative prose, or broad payloads.
- Do not promote a fix that closes wrong-side escapes by over-suppressing correct-side contribution.
- Do not increase visibility-depth resolution as the first fix; prior 12px/16px sweeps improved residual leak but opened directional suppression.

### Runtime Candidate

Prototype a conditional cross-bin fallback:

1. Load the exact octahedral visibility moment first.
2. If `hitConfidence > 0`, keep exact-bin behavior.
3. If `hitConfidence == 0`, load the four cross-adjacent oct bins.
4. For adjacent bins with `hitConfidence > 0`, compute the same Chebyshev visibility used by runtime.
5. Select the adjacent hit with the lowest computed visibility as the conservative replacement moment.
6. If no adjacent hit exists, preserve the no-hit exact-bin behavior.

This candidate targets the verified failure mode while bounding the extra load cost to no-hit exact-bin cases. An unconditional cross lookup may be used only as an upper-bound comparison; a 3x3 lookup is deferred unless cross lookup fails with evidence.

### Cost Ceiling

The prototype must report compact raw facts that allow the proof to distinguish quality from cost:

- exact visibility lookup count;
- conditional fallback activation count;
- adjacent moment load count;
- rescued no-hit escape count;
- fallback no-adjacent-hit count.

Promotion should require fallback activity to be bounded to the known no-hit class in the focused proof. If fallback activates broadly or materially worsens focused smoke runtime/timing evidence, reject it even if the escape gate closes.

### Proof-Gate Evidence Requirements

The `visibilityWeighting.noWrongSideEscape` gate must own the fallback verdict from compact raw facts, including:

- exact-bin no-hit escape count before and after fallback;
- fallback activation count;
- adjacent-hit rescue count;
- no-adjacent-hit fallback count;
- adjacent visibility load count;
- wrong-side escaped count after fallback;
- directional suppression and correct-bounce preservation evidence from their existing gates.

The residual leak gate remains separate: `sealedWall.preToneMaskedWrongSideResidualLeakRatio` must continue to report against the zero-leak oracle, even if adjacent-bin fallback closes `visibilityWeighting.noWrongSideEscape`.

### Over-Occlusion Safeguards

The proof must reject over-occlusion:

- `visibilityWeighting.directionalSuppression` must remain supported.
- Correct-bounce preservation gates must remain supported.
- SH mixed-color risk must remain supported.
- The residual leak gate must remain independent and must not be softened.
- Any candidate that closes `wrongSideEscapedCount` by suppressing correct-side contribution more than wrong-side contribution is rejected.

### Proof Ownership

Diagnostics may emit compact raw fallback facts only. Proof gates own:

- whether `visibilityWeighting.noWrongSideEscape` is supported;
- whether fallback cost is acceptable;
- whether over-occlusion occurred;
- whether residual leak remains open.

The proof summary may include fallback evidence only in open gate actuals or compact supported-gate evidence; it must not add diagnostic verdict prose.

### Focused Verification

The implementation slice must use focused no-build checks only:

- touched `node --check`;
- direct source invariant invocation;
- `git diff --check`;
- targeted Cornell WebGPU proof smoke.

The smoke proof must be interpreted through proof gates, not through scalar/WebGL baseline comparison. If Puppeteer cannot find its pinned browser, use the local Chrome executable path and record that in the verification note rather than changing the proof contract.

### Acceptance Outcome

Promote the runtime candidate only if focused Cornell proof smoke shows:

- `visibilityWeighting.noWrongSideEscape` becomes `SUPPORTED`;
- all previously supported gates remain supported;
- residual leak remains honestly reported against zero;
- compact source invariants pass;
- no runtime CPU readback/proof helper is introduced;
- no broad diagnostic payload is added.

### Rejection Outcome

If the candidate fails cost, suppression, bounce, SH-risk, residual-honesty, or compactness criteria, revert or keep it out of runtime and record the result as a rejected optimization. In that case, `visibilityWeighting.noWrongSideEscape` remains open as a known 8px octahedral visibility-moment exact-bin coverage limitation.

### Prototype Outcome

The adjacent-cross prototype is rejected. Conditional cross-bin fallback activated on the no-hit class and found adjacent hits, but `wrongSideEscapedCount` remained `4`; the unconditional-cross upper bound also left the escape gate open and regressed directional suppression plus receiver-surface agreement. Keep the rejected result in the ledger, but keep the runtime and proof interface free of adjacent fallback branches and fallback payloads. The adjacent-hit localization count remains because it classifies the failure; the failed-rescue counters do not.

### Modernization Direction

Future work should not try to make the leaky scalar-validity baseline look better. The missing product gaps are:

- visibility representation quality: DDGI-style distance/moment coverage, borders/gutters, and bias policy that scale with angular resolution. The current 8px setting is angular octahedral visibility resolution; external DDGI references commonly allocate more directional detail to visibility/distance than to irradiance, so this should be treated as a representation limitation, not just a constant to tweak;
- probe classification/relocation: interior/exterior separation, invalid-probe handling, and wall-aware sampling controls;
- GPU-resident product shape: grid volume sampling and material/object irradiance, not scene-global mutable probe state;
- proof compactness: raw facts stay compact, gates own verdicts, and failed-path evidence is not promoted into permanent payload bloat.

## Ultraplan Architecture

The architecture target is a deep LightProbeGridGPU runtime module with a small GPU-resident interface. The harness measures the module. Diagnostics emit compact raw facts. Proof gates own promotion verdicts. Research sources and rejected prototypes are ledger evidence, not runtime branches.

| Module | Interface | Implementation behind the seam | Depth / locality goal |
|--------|-----------|--------------------------------|-----------------------|
| `LightProbeGridGPU` runtime | Grid setup, bake, GPU textures, sampling controls, visibility-depth settings | Probe atlas, visibility-distance bake, TSL sampling, probe validity texture, material nodes | Keep runtime deep: callers get GI sampling without knowing proof readback or mirror logic |
| Visibility representation | Directional visibility lookup plus moment/bias policy | Octahedral visibility-distance tiles, gutters/borders candidate, Chebyshev/moment filtering, resolution-scaled bias | Concentrate 8px/12px/16px behavior in one seam so gates can test representation changes |
| Probe classification/relocation | Probe validity/classification facts and GPU sampling compatibility | Interior/exterior/invalid/occluding classification, relocation policy, wall-aware exclusion | Keep leak classification local instead of scattering fixture-specific checks |
| Diagnostics | Raw receiver, visibility, leak, SH, and surface facts | CPU mirror, readback, focused harness helpers | Keep diagnostics shallow but honest: no verdicts, no rejected-path payloads |
| Proof gates | Gate ids, thresholds, expected values, compact actuals | Promotion math and open-gate evidence | Gates own truth; runtime and diagnostics do not say "supported" |
| Ledger/roadmap | Decisions, rejected paths, next SDD phase | Research synthesis, source references, phase tasks | Preserve learning without keeping failed algorithms in live interfaces |

```mermaid
flowchart LR
	Runtime["LightProbeGridGPU runtime<br/>GPU-resident sampling"] --> Visibility["Visibility representation<br/>moments, bias, resolution"]
	Runtime --> Classification["Probe classification / relocation<br/>validity, wall awareness"]
	Visibility --> Diagnostics["Diagnostics<br/>compact raw facts"]
	Classification --> Diagnostics
	Diagnostics --> Gates["Proof gates<br/>verdict ownership"]
	Gates --> Ledger["Ledger + roadmap<br/>decisions and rejected paths"]
	Ledger -.guards.-> Runtime
	Ledger -.guards.-> Diagnostics
```

### Alignment Rules

- The first algorithmic SDD slice is visibility representation, not another scalar-baseline comparison.
- Probe classification/relocation is the second algorithmic lane because engine docs treat validity and relocation as first-class leak controls.
- Resolution changes are blocked until the candidate also defines resolution-scaled moment/bias policy and over-occlusion gates.
- Every rejected prototype must end with a trim pass: ledger keeps the decision; source invariants keep rejected payloads out of runtime, diagnostics, and proof facts.
- Promotion requires existing supported gates to stay supported: runtime readiness, projection parity, moment readback, directional suppression, receiver-surface agreement, SH-risk, correct bounce, and compact proof shape.
