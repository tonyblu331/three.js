# Tasks: LightProbeGridGPU Research-Proof Evals

## Review Workload Forecast

| Field | Value |
|-------|-------|
| Estimated changed lines | 220-360 |
| 400-line budget risk | Medium |
| Chained PRs recommended | No |
| Suggested split | Single focused cleanup unless scope expands |
| Delivery strategy | ask-on-risk |
| Chain strategy | pending |

Decision needed before apply: No
Chained PRs recommended: No
Chain strategy: pending
400-line budget risk: Medium

### Suggested Work Units

| Unit | Goal | Likely PR | Notes |
|------|------|-----------|-------|
| 1 | Freeze eval contract and compact current payloads | PR 1 | Current working diff plus SDD artifacts. |
| 2 | Move one verdict family into proof gates | PR 1 | Stop before broad harness surgery. |

## Phase 1: Contract Foundation

- [x] 1.1 Create `openspec/changes/lightprobegridgpu-research-proof-evals/research-claim.md` with falsifiable claim, enemy terms, and rejection gates.
- [x] 1.2 Create `openspec/changes/lightprobegridgpu-research-proof-evals/proof-ledger.md` tracking supported/open eval claims.
- [x] 1.3 Record SDD proposal/spec/design/tasks for the eval cleanup scope.

## Phase 2: Current Payload Cleanup

- [x] 2.1 Keep compact profiler diff in `examples/jsm/lighting/LightProbeGridGPUTestHarness.js`; preserve measured summaries and backend fallback evidence.
- [x] 2.2 Keep compact escape classification diff in `examples/jsm/lighting/LightProbeGridGPUVisibilityWeightingStudy.js`; aggregate counts once.
- [x] 2.3 Audit remaining `status`, `proofBoundary`, and `diagnosticConclusion` fields in `LightProbeGridGPUTestHarness.js`; classify raw fact vs verdict vs narrative.

## Phase 3: Gate Ownership Refactor

- [x] 3.1 Move one verdict-like diagnostic family into `test/e2e/lightprobegrid-gpu-proof-gates.js` when it has explicit thresholds.
- [x] 3.2 Update the relevant `test/e2e/lightprobegrid-gpu-runner-*.js` file to assert raw fact shape, not narrative status.
- [x] 3.3 Delete any now-unconsumed narrative payload from the harness.

## Phase 4: Verification

- [x] 4.1 Run `node --check` on touched harness, diagnostic, proof-gate, and runner files.
- [x] 4.2 Run direct `checkSmokeSourceInvariants(...)`.
- [x] 4.3 Run `git diff --check` and update `lightprobegrid-gpu-refactor-plan.md` only with current facts.

## Phase 5: Second Gate Ownership Refactor

- [x] 5.1 Move visibility-weighting directional suppression verdict out of `LightProbeGridGPUVisibilityWeightingStudy.js`.
- [x] 5.2 Add `visibilityWeighting.directionalSuppression` to compact proof gates.
- [x] 5.3 Update visibility runner/source invariants to assert raw diagnostic facts instead of narrative status, proofBoundary, interrogationFinding, or dominantEscapeReason.

## Phase 6: Remaining Verdict Audit

- [x] 6.1 Audit SH contribution and receiver GPU-debug diagnostics for the next gate-owned verdict candidate.

## Phase 7: Receiver Surface Gate Ownership Refactor

- [x] 7.1 Move receiver-surface CPU/render agreement verdict out of `LightProbeGridGPUReceiverDiagnostics.js`.
- [x] 7.2 Add `receiverSurface.cpuRenderAgreement` to compact proof gates.
- [x] 7.3 Update visibility runner/source invariants to assert raw receiver-surface facts instead of status/proofBoundary/cpuRenderAgreementGate.

## Phase 8: Remaining Verdict Audit

- [x] 8.1 Audit SH contribution and receiver GPU-debug diagnostics for any remaining status/proofBoundary payload that can be deleted or gate-owned.

## Phase 9: SH Contribution Gate Ownership Refactor

- [x] 9.1 Remove SH contribution status/proofBoundary/suspectedFailureDomain payload from `LightProbeGridGPUShDiagnostics.js`.
- [x] 9.2 Add `shContribution.noBakedMixedColorRisk` to compact proof gates.
- [x] 9.3 Update visibility runner/source invariants to assert raw SH contribution facts instead of suspected failure-domain narrative.

## Phase 10: Remaining Verdict Audit

- [x] 10.1 Audit receiver GPU-debug diagnostic; decide whether its open status can be deleted as narrative or needs an explicit opt-in debug gate.

## Phase 11: GPU-Debug Narrative Cleanup

- [x] 11.1 Remove receiver GPU-debug status/proofBoundary/reason payload from `LightProbeGridGPUReceiverDiagnostics.js`.
- [x] 11.2 Remove placeholder GPU-debug agreement gates from the compact diagnostic summary.
- [x] 11.3 Update visibility runner/source invariants to assert raw GPU-debug availability/surface facts only.

## Phase 12: Remaining Verdict Audit

- [x] 12.1 Audit visibility moment and leak proof endpoint status/proofBoundary fields for the next raw-fact/gate ownership cleanup.
- [x] 12.2 Remove visibility moment `evidenceStatus`/`proofBoundary` payload from `LightProbeGridGPUTestHarness.js`; keep raw availability/mode/readback facts.
- [x] 12.3 Remove sealed-wall leak proof `proofBoundary`, `status`, and `linearPromotionStatus` payload from `LightProbeGridGPUTestHarness.js`; keep raw threshold metrics.
- [x] 12.4 Run final focused syntax, source-invariant, synthetic proof-gate, and `git diff --check` verification after the leak proof cleanup.

## Phase 13: Projection Profiler Raw-Fact Cleanup

- [x] 13.1 Audit `inspectComputeProjectionProfiling()` for diagnostic status/policy payload not consumed by proof gates.
- [x] 13.2 Remove profiler `status`, `timingPolicy`, `timingGated`, `gpuTimerQueryStatus`, and `projectionPhaseTimingStatus`; keep timing sources, static work, medians, and backend/fallback facts.
- [x] 13.3 Update core runner/source invariants to assert raw profiler shape instead of diagnostic status strings.
- [x] 13.4 Run final focused syntax, source-invariant, synthetic proof-gate, and `git diff --check` verification after the profiler cleanup.

## Phase 14: Projection Runtime Parity Gate Ownership

- [x] 14.1 Audit `inspectComputeProjectionRuntimeParity()` consumers for verdict-like `status`/`statusTransition` fields.
- [x] 14.2 Remove runtime parity `status` and `statusTransition`; keep backend, tolerance, coefficient, atlas, and fallback facts.
- [x] 14.3 Update proof gates and core assertions to derive the parity verdict from raw `tolerancePass` and threshold facts.
- [x] 14.4 Run final focused syntax, source-invariant, synthetic proof-gate, and `git diff --check` verification after the runtime parity cleanup.

## Phase 15: Projection Oracle Raw-Fact Cleanup

- [x] 15.1 Audit projection parity candidate, adapter fallback, parity contract, and atlas repack oracle payloads for proof-only status strings.
- [x] 15.2 Remove projection oracle `status`, transition, and pending/promotion labels; keep raw paths, capabilities, thresholds, and deltas.
- [x] 15.3 Update core assertions/source invariants to assert raw projection oracle facts instead of proof-only status strings.
- [x] 15.4 Run final focused syntax, source-invariant, synthetic proof-gate, and `git diff --check` verification after the projection oracle cleanup.

## Phase 16: Artifact Pressure Raw-Fact Cleanup

- [x] 16.1 Audit artifact pressure `status` producers and proof-validation consumers.
- [x] 16.2 Remove artifact pressure `status` from harness and image metric helpers; keep black-tail, luminance, and contrast facts.
- [x] 16.3 Update proof-validation/source invariants to derive pressure/bounded assertions from raw thresholds.
- [x] 16.4 Run final focused syntax, source-invariant, synthetic proof-gate, and `git diff --check` verification after artifact pressure cleanup.

## Phase 17: Artifact Snapshot Narrative Cleanup

- [x] 17.1 Audit artifact snapshot `referenceBoundary` and anti-ringing `action` prose payloads.
- [x] 17.2 Remove prose boundary/action payload from WebGPU/WebGL artifact snapshots; keep structured `proofRole` and `antiRingingPolicy` facts.
- [x] 17.3 Update proof validation to assert structured role/policy fields instead of prose boundary text.
- [x] 17.4 Run final focused syntax, source-invariant, synthetic proof-gate, and `git diff --check` verification after artifact snapshot narrative cleanup.

## Phase 18: Final Narrative Sweep

- [x] 18.1 Audit remaining `reason`, `referenceBoundary`, and `action` payloads in harness/diagnostic outputs.
- [x] 18.2 Remove projection adapter fallback prose `reason`; keep selected path, fallback flag, capability, and runtime guard facts.
- [x] 18.3 Run final focused syntax, source-invariant, synthetic proof-gate, and `git diff --check` verification after the narrative sweep.

## Phase 19: Leak Evidence Shape Cleanup

- [x] 19.1 Tighten receiver-surface agreement so `surfaceCpuRenderDelta` compares surface render capture only against surface CPU quadrature, not masked visible-pixel leak ratios.
- [x] 19.2 Remove tone-mapped sealed-wall wrong-side improvements as promotion-blocking proof gates; keep the linear pre-tone masked leak improvement and correct-bounce preservation gates.
- [x] 19.3 Update source invariants, roadmap, and proof ledger to guard the new evidence ownership shape.
- [x] 19.4 Run focused no-build verification after the leak evidence cleanup.

## Phase 20: Density Fixture Proof-Validation Cleanup

- [x] 20.1 Extract density-specific budget and same-fixture predicates in proof validation.
- [x] 20.2 Update source invariants and roadmap to guard named density fixture proof checks instead of repeated inline field chains.
- [x] 20.3 Run focused no-build verification after the proof-validation cleanup.

## Phase 21: Projection Oracle Runner Assertion Cleanup

- [x] 21.1 Extract core runner projection parity contract, compute candidate, adapter fallback, and atlas repack checks into named raw-fact predicates.
- [x] 21.2 Update source invariants and roadmap to guard the named projection-oracle predicate seams.
- [x] 21.3 Run focused no-build verification after the runner assertion cleanup.

## Phase 22: Visibility Runner Assertion Cleanup

- [x] 22.1 Extract visibility runner moment, weighting, escape, SH contribution, receiver-surface, and receiver-normal checks into named raw-fact predicates.
- [x] 22.2 Update source invariants and roadmap to guard the named visibility predicate seams.
- [x] 22.3 Run focused no-build verification after the visibility runner cleanup.

## Phase 23: Matrix Runner Assertion Cleanup

- [x] 23.1 Extract matrix runner probe occupancy, leak-proof fixture, leak-proof row, and restoration checks into named raw-fact predicates.
- [x] 23.2 Update source invariants and roadmap to guard the named matrix predicate seams.
- [x] 23.3 Run focused no-build verification after the matrix runner cleanup.

## Phase 24: Runtime Runner Assertion Cleanup

- [x] 24.1 Extract runtime runner bake-coalescing, benchmark backend/memory/visibility-depth/timing, and color-sanity checks into named raw-fact predicates.
- [x] 24.2 Update roadmap and proof ledger to record the runtime runner predicate seam.
- [x] 24.3 Run focused no-build verification after the runtime runner cleanup.

## Phase 25: Core Runtime Parity/Profile Assertion Cleanup

- [x] 25.1 Extract core runner compute projection runtime parity and profiling checks into named raw-fact predicates.
- [x] 25.2 Update source invariants, roadmap, and proof ledger to guard the named core parity/profile seams.
- [x] 25.3 Run focused no-build verification after the core runner cleanup.

## Phase 26: Proof Summary Validation Cleanup

- [x] 26.1 Extract proof-summary gate-count, id, compact-shape, required-supported, and byte-budget checks into named predicates.
- [x] 26.2 Update source invariants, roadmap, and proof ledger to guard the named proof-summary validation seam.
- [x] 26.3 Run focused no-build verification after the proof-summary cleanup.

## Phase 27: Density Row Proof-Validation Cleanup

- [x] 27.1 Extract density reference, shadowless, crisp-shadow, and damped row checks into named proof-validation predicates.
- [x] 27.2 Fix the density damped row assertion so its message is a real assertion message, not part of the boolean expression.
- [x] 27.3 Update source invariants, roadmap, and proof ledger to guard the named density row validation seam.
- [x] 27.4 Run focused no-build verification after the density row cleanup.

## Phase 28: Low-Res Proof-Validation Cleanup

- [x] 28.1 Extract low-res shared-intensity, band-isolation, bounce-preservation, and damped-comparison checks into named predicates.
- [x] 28.2 Update source invariants, roadmap, and proof ledger to guard the named low-res validation seam.
- [x] 28.3 Run focused no-build verification after the low-res proof-validation cleanup.

## Phase 29: Density Damped Predicate Split

- [x] 29.1 Split density damped fixture-preservation and math-action checks into separate named predicates.
- [x] 29.2 Update source invariants, roadmap, and proof ledger to guard the split density damped validation seam.
- [x] 29.3 Run focused no-build verification after the density damped predicate split.

## Phase 30: Density Crisp-Shadow Predicate Split

- [x] 30.1 Split density crisp-shadow row facts from cross-row reference comparison facts.
- [x] 30.2 Update source invariants, roadmap, and proof ledger to guard the split crisp-shadow validation seam.
- [x] 30.3 Run focused no-build verification after the density crisp-shadow predicate split.

## Phase 31: Receiver-Surface Agreement Ownership

- [x] 31.1 Change receiver-surface diagnostics to emit raw render and CPU surface wrong-ratio facts instead of a pre-derived delta.
- [x] 31.2 Derive receiver-surface CPU/render delta once inside proof gates with matching max-to-max aggregation, then feed that same derived fact to both the receiver-surface predicate and gate actual.
- [x] 31.3 Update runner assertions, source invariants, roadmap, and proof ledger to guard proof-gate ownership of receiver-surface agreement.
- [x] 31.4 Run focused no-build verification after the receiver-surface agreement ownership cleanup.

## Phase 32: Visibility Status Payload Cleanup

- [x] 32.1 Remove the unused `deriveVisibilityProofStatus()` wrapper and its `visibilityLabel`/`visibilityStatus`/`ddgiStatus` verdict payload.
- [x] 32.2 Keep moment-backed visibility validation on the raw `isMomentBackedVisibility()` predicate.
- [x] 32.3 Update source invariants, roadmap, and proof ledger to guard against reintroducing unused visibility/DDGI status payloads.
- [x] 32.4 Run focused no-build verification after the visibility status payload cleanup.

## Phase 33: Leak Evidence Artifact Visibility

- [x] 33.1 Write compact `leak-proof-facts.json` alongside `proof-summary.json` so baseline and visibility-moment leak rows remain directly auditable.
- [x] 33.2 Keep the artifact raw: sealed-wall fixture/settings/sampling plus the two baseline/candidate leak rows, without proof-gate verdicts or nested metric snapshots.
- [x] 33.3 Add artifact/source-invariant guards for finite raw leak and bounce metrics.
- [x] 33.4 Run focused no-build verification after the leak evidence artifact cleanup.

## Phase 34: Finite Proof Goal and Ground-Truth Oracle

- [x] 34.1 Reframe the roadmap around a finite proof package instead of endless payload cleanup.
- [x] 34.2 Add the sealed-wall ground-truth oracle (`wrongSideLeakTarget: 0`) to compact leak artifacts.
- [x] 34.3 Add proof-gate derivation for residual pre-tone masked wrong-side leak against the zero-leak oracle, separate from baseline-vs-candidate improvement.
- [x] 34.4 Guard the ground-truth oracle and residual leak proof shape with source invariants.
- [x] 34.5 Run focused no-build verification after the ground-truth oracle cleanup.

## Phase 35: Receiver-Surface Runtime Mirror Fix

- [x] 35.1 Identify the CPU receiver-surface diagnostic mismatch source: SH diagnostics blended coefficients using `visibilityWeightFloor` instead of mirroring runtime `visibilityMass`.
- [x] 35.2 Change SH diagnostics to compute runtime wrong-ratio from visibility irradiance scaled by `visibilityWeight / scalarWeight`, matching the runtime shader shape.
- [x] 35.3 Guard the runtime-mirror formula with source invariants so the stale `visibilityWeightFloor` blend cannot return.
- [x] 35.4 Run focused no-build verification after the receiver-surface mirror fix.

## Phase 36: SH Mixed-Color Risk Predicate Tightening

- [x] 36.1 Classify the SH mixed-color proof gate as over-broad because it promoted intermediate visibility aggregate wrong-ratio into final runtime risk.
- [x] 36.2 Tighten `shContribution.noBakedMixedColorRisk` to use runtime wrong-ratio plus hard wrong-side escape evidence.
- [x] 36.3 Guard the tightened runtime-risk predicate with source invariants.
- [x] 36.4 Run focused no-build verification after the SH-risk predicate tightening.

## Phase 37: Final Proof Package Framing

- [x] 37.1 Add a one-sentence final proof claim to the roadmap.
- [x] 37.2 Add explicit non-claims for perfect GI, zero leak, leaky baseline as ground truth, tone-mapped promotion, intermediate SH drift, and unrefreshed receiver-surface values.
- [x] 37.3 Mark refreshed focused eval proof as the remaining final evidence gap instead of adding more cleanup scope.
- [x] 37.4 Run focused no-build verification after the final proof package framing.

## Phase 38: Visibility Escape Gate Ownership

- [x] 38.1 Rerun focused Cornell proof smoke and inspect compact proof gates.
- [x] 38.2 Reclassify `wrongSideEscapedCount = 4` as visibility escape evidence instead of SH mixed-color risk because SH runtime wrong-ratio is low (`0.0318 < 0.25`).
- [x] 38.3 Add `visibilityWeighting.noWrongSideEscape` as the proof-gate owner for wrong-side escape evidence.
- [x] 38.4 Run focused no-build verification and refreshed proof smoke after the gate ownership split.

## Phase 39: Compact Escape Subcount Evidence

- [x] 39.1 Add compact open-gate evidence for visibility-bias and front-edge bypass escape subcounts.
- [x] 39.2 Rerun focused Cornell proof smoke and confirm the four wrong-side escapes are not visibility-bias or front-edge bypass cases.
- [x] 39.3 Run focused no-build verification after the compact escape evidence update.

## Phase 40: True Escape Reason Evidence

- [x] 40.1 Add compact true-escape reason counts for receiver-before-mean, high-Chebyshev, and weak-crush/weighting escapes.
- [x] 40.2 Surface those counts only through the visibility escape gate evidence, keeping row dumps and per-probe arrays out of proof artifacts.
- [x] 40.3 Rerun focused Cornell proof smoke and confirm the remaining sealed-wall escapes are `receiverBeforeMeanEscapeCount = 2`, `highChebyshevEscapeCount = 0`, and `weakCrushEscapeCount = 2`.
- [x] 40.4 Run focused no-build verification after the compact true-escape reason update.

## Phase 41: Double-Sided Visibility Distance Capture

- [x] 41.1 Make the visibility-distance override material double-sided so moment captures do not depend on mesh front-face orientation.
- [x] 41.2 Guard double-sided visibility-distance capture with source invariants.
- [x] 41.3 Rerun focused Cornell proof smoke and confirm the receiver-before-mean subcase is gone while `wrongSideEscapedCount = 4` remains as weak-crush/weighting evidence.
- [x] 41.4 Test and reject the more aggressive partial-hit Chebyshev heuristic because it did not improve escape or leak metrics.
- [x] 41.5 Run focused no-build verification after the visibility-distance capture update.

## Phase 42: Weak-Crush No-Hit Classification

- [x] 42.1 Add compact weak-crush subcounts for partial-hit, full-hit, no-hit, and near-threshold escape cases.
- [x] 42.2 Surface the weak-crush subcounts only through the visibility escape gate evidence.
- [x] 42.3 Rerun focused Cornell proof smoke and confirm all four weak-crush escapes are no-hit moment coverage misses.
- [x] 42.4 Run focused no-build verification after the weak-crush classification update.

## Phase 43: Visibility Angular Resolution Sweep

- [x] 43.1 Test 16px visibility-depth angular resolution and record that it improves residual leak but opens directional suppression.
- [x] 43.2 Test 12px visibility-depth angular resolution and record that it partially improves residual leak but still opens directional suppression.
- [x] 43.3 Test 10px visibility-depth angular resolution and record that it preserves gate shape but does not improve the blocking residual leak metric.
- [x] 43.4 Revert visibility-depth angular resolution to 8px because the sweep is not a clean proof fix.
- [x] 43.5 Run focused no-build verification after reverting the resolution sweep.

## Phase 44: Receiver-Surface Raw Gate Evidence

- [x] 44.1 Change the receiver-surface open gate actual from a naked delta to compact raw render/CPU inputs plus the derived delta.
- [x] 44.2 Guard the receiver-surface evidence owner with source invariants.
- [x] 44.3 Rerun focused Cornell proof smoke and record `renderSurfaceWrongRatio = 0.8219`, `surfaceRuntimeWrongRatioMax = 0.1263`, and `surfaceCpuRenderDelta = 0.6956`.
- [x] 44.4 Update roadmap and proof ledger so the remaining receiver-surface decision targets render/surface-capture disagreement.


## Phase 45: Receiver-Surface Center Capture Evidence

- [x] 45.1 Add compact receiver-surface center render wrong-ratio evidence to distinguish broad surface-region contamination from interior receiver disagreement.
- [x] 45.2 Surface the center fact only through receiver-surface diagnostic/proof-gate evidence.
- [x] 45.3 Rerun focused Cornell proof smoke and record `renderSurfaceCenterWrongRatio = 0.9314`, worse than broad `renderSurfaceWrongRatio = 0.8219`, while CPU runtime mirror remains `0.1263`.
- [x] 45.4 Classify the receiver-surface open gate as render/runtime diagnostic disagreement, not an overbroad projected surface-region artifact.


## Phase 46: Receiver-Surface Runtime-Irradiance Evidence

- [x] 46.1 Add compact receiver-center render evidence using `probeGrid.createIrradianceNode()` on an unlit basic material to separate runtime irradiance from standard-material shading.
- [x] 46.2 Add compact center CPU mirror evidence and an irradiance-center CPU/render delta in proof-gate actuals.
- [x] 46.3 Rerun focused Cornell proof smoke and record `renderIrradianceCenterWrongRatio = 0.5882`, `centerRuntimeWrongRatioMax = 0.0635`, and `irradianceCenterCpuRenderDelta = 0.5247`.
- [x] 46.4 Classify receiver-surface as a CPU mirror/runtime-node disagreement; standard material shading increases the visible wrong ratio, but runtime irradiance alone is already above the CPU center mirror.


## Phase 47: Receiver-Surface Linear-Irradiance Gate Fix

- [x] 47.1 Stop using display-mapped standard-material surface ratios as the receiver-surface CPU/render agreement metric.
- [x] 47.2 Derive `receiverSurface.cpuRenderAgreement` from linear unlit runtime-irradiance center render versus CPU center runtime mirror.
- [x] 47.3 Keep display-space surface and sRGB irradiance deltas as compact evidence only, not as the pass/fail metric.
- [x] 47.4 Rerun focused Cornell proof smoke and confirm proof summary moves to 14 supported / 2 open gates.


## Phase 48: Final Bounded Proof Package

- [x] 48.1 Add final proof package notes listing the supported gates, open gates, non-claims, and exact bounded leak-improvement claim.
- [x] 48.2 Keep the final claim honest: improvement versus the leaky scalar-validity baseline is about `5.8%`, while residual leak remains `0.942` against the zero-leak oracle.
- [x] 48.3 Mark receiver-surface as supported only for linear unlit runtime irradiance agreement; display-space surface ratios remain diagnostics.


## Phase 49: No-Wrong-Side Escape Localization

- [x] 49.1 Add compact gate-owned no-hit localization counters for divider crossing, segment intersection, receiver/probe direction mismatch, adjacent oct-bin hits, all-adjacent no-hit misses, distinct oct bins, and visibility-depth resolution.
- [x] 49.2 Rerun focused Cornell proof smoke and classify the remaining four escapes as 8px exact-oct-bin no-hit misses with adjacent-bin coverage.
- [x] 49.3 Keep `visibilityWeighting.noWrongSideEscape` open because the gate still reports `wrongSideEscapedCount = 4`; do not soften the residual leak gate or use scalar/WebGL baselines as truth.
- [x] 49.4 Run focused no-build verification after the no-hit localization update.


## Phase 52: Residual Leak Classification Closeout

- [x] 52.1 Rerun focused Cornell proof smoke and confirm the proof remains `OPEN` with 14 supported / 2 open gates.
- [x] 52.2 Confirm the remaining visibility escapes are classified as four 8px exact-oct-bin no-hit misses with adjacent-bin coverage, not receiver/probe direction mismatch, front-edge bypass, high-Chebyshev, or SH mixed-color risk.
- [x] 52.3 Classify `sealedWall.preToneMaskedWrongSideResidualLeakRatio = 0.942` as out-of-scope for this bounded patch because no clean GPU-resident visibility/probe-sampling fix materially reduces it without opening another gate.
- [x] 52.4 Keep the final claim honest: `0.8626` to `0.8126` pre-tone masked wrong-side leak improvement versus the leaky scalar-validity baseline, with residual leak still reported against the zero-leak oracle.


## Phase 53: Adjacent Visibility-Moment Rescue SDD

- [x] 53.1 Define the SDD goal: prove whether bounded GPU-resident adjacent lookup can eliminate the four exact-bin no-hit escapes without regressing suppression, bounce, compactness, or residual-leak honesty.
- [x] 53.2 Define the ideal state: `visibilityWeighting.noWrongSideEscape` supported with `wrongSideEscapedCount = 0`, while residual leak remains independently reported against the zero-leak oracle.
- [x] 53.3 Define non-goals: no threshold tuning, no baseline-as-truth, no CPU readback in runtime, no broad payloads, and no resolution increase as the first fix.
- [x] 53.4 Specify the preferred runtime candidate: exact-bin first, conditional cross-bin fallback only when hit confidence is zero, choose the adjacent hit with lowest computed Chebyshev visibility, and preserve no-hit behavior when no adjacent hit exists.
- [x] 53.5 Define cost-ceiling evidence: exact lookup count, fallback activation count, adjacent load count, rescued no-hit escape count, and no-adjacent-hit fallback count.
- [x] 53.6 Define over-occlusion rejection criteria: directional suppression, correct bounce, SH-risk, compactness, and residual-leak honesty must not regress.
- [x] 53.7 Define proof-gate evidence requirements, keeping fallback verdicts gate-owned and residual leak independent.
- [x] 53.8 Define focused verification: touched `node --check`, source invariants, `git diff --check`, and targeted Cornell WebGPU proof smoke.
- [x] 53.9 Define acceptance and rejection outcomes for the research prototype before implementation.


## Phase 54: Adjacent Visibility-Moment Rescue Prototype

- [x] 54.1 Add source invariants for GPU-resident adjacent lookup and compact fallback facts.
- [x] 54.2 Prototype conditional cross-bin fallback in runtime visibility sampling.
- [x] 54.3 Add compact raw fallback activity facts consumed by `visibilityWeighting.noWrongSideEscape` and any cost/over-occlusion proof checks.
- [x] 54.4 Run touched `node --check`, source invariants, and `git diff --check`.
- [x] 54.5 Run targeted Cornell WebGPU proof smoke and record that conditional-cross fallback activates 11 times, loads 44 adjacent moments, rescues 5, but leaves `wrongSideEscapedCount = 4`.
- [x] 54.6 Compare the unconditional-cross upper bound after conditional-cross does not close cleanly; it still leaves `wrongSideEscapedCount = 4` and opens directional suppression (`0.1838`) plus receiver-surface agreement (`0.2422`).
- [x] 54.7 Reject promotion because neither adjacent-cross variant closes no-wrong-side without opening other gates.
- [x] 54.8 Remove the adjacent lookup from runtime/mirror code and keep the gate open as a known 8px exact-bin visibility-moment limitation.


## Phase 55: External Baseline And Modernization Framing

- [x] 55.1 Verify upstream three.js probe-volume history: `#16228` requests light-probe interpolation, and `#18371` discusses grid volumes, per-object/material irradiance, HDR data, and GPU-friendly sampling.
- [x] 55.2 Record that the scalar/WebGL and old LightProbe paths are leaky comparators/problem statements, not ground truth.
- [x] 55.3 Cross-check external sources: DDGI/RTXGI papers/blogs, Unity APV docs, Flax/SDFGI docs, three.js forum/PR history, and Reddit practitioner threads point to visibility, validity, relocation/classification, and layer separation as leak controls. Treat Reddit as corroboration, not primary proof.
- [x] 55.4 Update roadmap, design, and proof ledger so the next healthy gap is visibility representation or probe classification/relocation, while adjacent fallback and threshold tuning stay rejected.
- [x] 55.5 Keep the trim rule explicit: no new diagnostic field unless a proof gate, artifact contract, or public example consumes it.


## Phase 56: Rejected Adjacent-Fallback Payload Trim

- [x] 56.1 Remove the rejected adjacent-fallback evaluator from `LightProbeGridGPUVisibilityWeightingStudy.js` so the diagnostic mirrors exact-bin visibility weighting again.
- [x] 56.2 Remove `adjacentFallback*` counters from visibility-study facts, proof facts, proof-gate evidence, and runner assertions.
- [x] 56.3 Keep adjacent-hit localization evidence because it classifies the 8px exact-bin no-hit misses; do not keep failed-rescue counters.
- [x] 56.4 Add source-invariant absence guards for rejected adjacent-fallback payloads.
- [x] 56.5 Verify touched syntax, source invariants, and diff hygiene.


## Phase 57: Visibility Representation SDD

- [ ] 57.1 Define the visibility representation interface: angular resolution, moment filtering, bias policy, border/gutter handling, and over-occlusion guard facts.
- [ ] 57.2 Add a design note that explains why the current 8px exact-bin behavior fails and why raw 12px/16px resolution sweeps are not sufficient.
- [ ] 57.3 Prototype one representation candidate behind the visibility seam without adding CPU readback or proof helpers to runtime.
- [ ] 57.4 Emit compact raw candidate facts only: resolution, effective bias, moment-hit coverage, wrong-side escape count, and wrong-minus-correct suppression.
- [ ] 57.5 Reject or promote through existing proof gates; do not add a new gate that merely renames residual leak.


## Phase 58: Probe Classification And Relocation SDD

- [ ] 58.1 Define classification categories for this proof: valid, invalid, interior, exterior, occluding, relocated.
- [ ] 58.2 Decide which facts are runtime sampling metadata versus proof-only diagnostic evidence.
- [ ] 58.3 Prototype wall-aware probe classification/relocation with compact aggregate facts, not per-probe row dumps.
- [ ] 58.4 Gate classification against wrong-side escape reduction, correct-bounce preservation, and directional suppression.
- [ ] 58.5 Reject any brightness-derived validity shortcut or fixture-only hack.


## Phase 59: Bias And Resolution Coupling

- [ ] 59.1 Re-run 8/10/12/16 only after a candidate defines resolution-scaled moment/bias policy.
- [ ] 59.2 Record residual leak, wrong-side escape count, directional suppression, receiver-surface agreement, SH-risk, and bounce for each resolution.
- [ ] 59.3 Promote a resolution only if it improves representation evidence without opening previously supported gates.
- [ ] 59.4 Keep `VISIBILITY_DEPTH_RESOLUTION = 8` unless the coupled candidate proves a better default.


## Phase 60: Product API Shape

- [ ] 60.1 Audit public and example-facing controls for GPU-resident grid-volume sampling, object/material irradiance direction, and proof-scoped diagnostics.
- [ ] 60.2 Keep scalar/WebGL comparison language as "same-class reference" or "leaky comparator", never oracle.
- [ ] 60.3 Document which controls are product controls versus proof-only diagnostics.
- [ ] 60.4 Reject scene-global mutable `LightProbe` state as the modernization target for this GPU module.


## Phase 61: Proof Compactness

- [ ] 61.1 After every rejected prototype, remove its runtime branches, diagnostic counters, proof-fact fields, and assertion expectations.
- [ ] 61.2 Keep only raw facts consumed by proof gates, artifact contracts, or public examples.
- [ ] 61.3 Add source-invariant absence guards for rejected-path payloads.
- [ ] 61.4 Run touched syntax checks, direct source invariants, and `git diff --check`.


## Phase 56: Cross-Bin Bake Dilation Closeout

- [x] 56.1 Add bounded one-pixel cardinal taps to the GPU visibility-moment repack so exact bins can capture nearby angular occluder coverage without adding runtime sampling loads.
- [x] 56.2 Guard the promoted bake shape with source invariants and keep runtime free of CPU readback/proof helpers.
- [x] 56.3 Run focused Cornell proof smoke and record that the safe cross dilation keeps 14 supported / 2 open gates, leaves `wrongSideEscapedCount = 4`, and improves residual leak from `0.942` to `0.9377`.
- [x] 56.4 Test the stronger one-pixel diagonal dilation and reject it because it reduces escapes to `3` but opens `receiverSurface.cpuRenderAgreement` and `shContribution.noBakedMixedColorRisk`.
- [x] 56.5 Keep both open gates honest: `visibilityWeighting.noWrongSideEscape` remains a compact exact-bin no-hit limitation, and `sealedWall.preToneMaskedWrongSideResidualLeakRatio` remains open against the zero-leak oracle.
