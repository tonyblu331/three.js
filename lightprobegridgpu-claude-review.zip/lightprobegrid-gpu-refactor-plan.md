# LightProbeGridGPU refactor roadmap

Verified: 2026-06-02 on branch `dev`.

## Goal

Ship a finite LightProbeGridGPU proof patch, not an endless refactor.

The patch is done when visibility-moment guarded sampling:

- stays GPU-resident at runtime;
- shows a bounded sealed-wall leak reduction versus the scalar-validity baseline;
- preserves correct bounce;
- reports residual leak against the physical zero-leak sealed-wall oracle;
- leaves proof verdicts in proof gates, not in runtime/diagnostic payloads;
- has any remaining receiver-surface or SH-risk gaps either fixed or explicitly classified as known diagnostics.

This is not a claim of perfect DDGI/GI, not a full global-illumination rewrite, and not a general cleanup project.

## North star

LightProbeGridGPU should be a deep runtime module with a small GPU-resident interface. Harnesses and diagnostics should emit compact raw facts only. Proof gates own thresholds, verdicts, and promotion decisions. If a field is not consumed by a gate, artifact contract, or public example, delete it instead of moving it. The proof must never treat a leaky baseline as ground truth: WebGL/scalar-validity comparisons are same-class references, while the sealed-wall physical oracle is wrong-side leak `0`.

## Modernization read

The old three.js LightProbe/LightProbeVolume direction is a useful problem statement, not a success oracle. Upstream discussion in `mrdoob/three.js#16228` and `#18371` already identified the missing product shape: interpolate probe data for objects/materials, keep grid volumes GPU-friendly, avoid arbitrary tetrahedral complexity, prefer HDR probe data, and separate probes/irradiance from scene lights. Beating the scalar-validity baseline is therefore only a bounded comparison; the implementation should modernize the missing visibility and sampling model instead of calling the baseline truth.

External GI practice points the same way. The current `8px` value is angular octahedral visibility texel resolution, not screen-space pixel size. DDGI practice separates low-frequency irradiance from higher-fidelity visibility: Morgan McGuire's DDGI overview describes tiny irradiance tiles but 16x16 visibility/distance tiles with borders, and Flax documents depth plus Chebyshev visibility weighting as its leak-control path. That makes an 8px visibility-depth tile a compact experiment, not a modern success criterion. Unity APV uses validity, virtual offset, dilation, rendering-layer masks, probe adjustment volumes, and density controls to keep probes from sampling through walls. Flax/SDFGI-style work also uses depth/SDF information for relocation/classification and leak reduction. Practitioner discussions on Reddit show the same failure mode in small probe experiments, but those are corroboration only; the decision should rest on papers, engine docs, and measured gates. The next healthy work is therefore classification/relocation or a better visibility representation, not another threshold tweak or proof payload expansion.

## Healthy trim rule

Trim anything that only explains why a rejected path failed after the proof gate already records it. Keep:

- compact raw facts consumed by proof gates;
- source invariants that protect runtime GPU residency and payload compactness;
- the final bounded proof package.

Delete or avoid:

- speculative adjacent-fallback runtime branches after rejection;
- row dumps, per-probe arrays, prose verdicts, and duplicated gate math;
- new gates that merely rename the same residual leak without a new source-backed fix.

## Stop rule

Stop adding roadmap scope when these four decisions are closed:

1. leak proof: baseline-vs-candidate and zero-oracle residual are both represented honestly;
2. receiver-surface mismatch: fixed, or documented as non-blocking diagnostic evidence with source proof;
3. SH mixed-color risk: fixed, or documented as expected/known low-order SH leakage with source proof;
4. final proof package: focused checks pass and PR notes state exactly what is proven and what remains unproven.

Any new task must directly close one of those four decisions. Otherwise it is out of scope.

## Definition of done

- Runtime stays free of proof readback helpers and CPU mirror logic.
- `leak-proof-facts.json` records compact baseline/candidate leak rows plus the sealed-wall ground-truth oracle (`wrongSideLeakTarget: 0`).
- Proof gates support runtime readiness, projection parity, visibility moment readback, leak improvement versus baseline, and correct-bounce preservation.
- Proof gates also report residual leak to the zero-leak oracle; that residual is diagnostic evidence, not a false promotion claim.
- Receiver-surface linear irradiance agreement and SH mixed-color risk are fixed/supported; display-space surface ratios remain diagnostics and do not invalidate the bounded leak-improvement claim.
- The roadmap ends at final proof package and PR notes; no new cleanup phase is allowed unless it directly closes one of the above bullets.

## Final proof claim

Visibility-moment guarded sampling is ready to present as a bounded leak-improvement proof patch when the refreshed Cornell proof run confirms the current source-level fixes: runtime remains GPU-resident, compact proof gates own verdicts, receiver-surface linear irradiance agreement is supported, sealed-wall leak evidence shows a small pre-tone masked improvement versus the scalar-validity baseline, correct bounce is preserved, and residual wrong-side leak remains reported against the zero-leak oracle.



## Final proof package notes

This patch is ready to present as a bounded proof patch, not a complete zero-leak GI solution.

Supported gates in the latest focused Cornell proof: runtime readiness/texture/bounds, projection runtime parity, projection coefficient and atlas deltas, visibility moment readback, receiver-normal agreement, directional suppression, receiver-surface linear irradiance CPU/render agreement, SH mixed-color risk, correct-bounce preservation, baseline-vs-candidate pre-tone masked leak improvement, and pre-tone masked correct-bounce preservation.

Open gates in the latest focused Cornell proof:

- `visibilityWeighting.noWrongSideEscape`: four wrong-side escapes remain after the promoted cross-bin bake dilation. Compact gate-owned evidence still classifies them as an 8px octahedral visibility-moment coverage limitation: all four are no-hit exact-bin misses (`weakCrushNoHitEscapeCount = 4`) on divider-crossing segments (`weakCrushNoHitCrossingCount = 4`, visibility/surface segment hit counts `4/4`), with receiver/probe direction mismatch `0`; all four have adjacent oct-bin hits (`weakCrushNoHitAdjacentHitCount = 4`, all-adjacent-no-hit `0`, distinct bins `4`).
- `sealedWall.preToneMaskedWrongSideResidualLeakRatio`: residual leak is reduced from `0.942` to `0.9377` against the physical zero-leak oracle. The scalar-validity baseline is leaky and must not be treated as ground truth.

Final bounded claim for PR notes: visibility-moment guarded sampling remains GPU-resident, keeps verdict ownership in proof gates, improves sealed-wall pre-tone masked wrong-side leak from `0.8626` to `0.8089` versus the scalar-validity baseline, preserves correct bounce (`0.9946`, pre-tone masked `1.0664`), supports receiver-surface linear irradiance agreement, and honestly reports the remaining no-hit visibility escapes plus high residual leak against the zero-leak oracle.

Closeout decision: `sealedWall.preToneMaskedWrongSideResidualLeakRatio` remains open for this bounded proof patch. The promoted cross-bin bake dilation reduces residual leak slightly without regressing supported gates, but the surviving visibility evidence still points to 8px octahedral moment exact-bin no-hit misses with adjacent-bin coverage. Reducing this further likely needs a broader algorithmic change such as higher-quality directional visibility coverage, wall-aware relocation/classification, or a different visibility representation, not threshold tuning or a leaky-baseline comparison.

## Non-claims

- This does not prove perfect DDGI/GI or zero leak.
- This does not treat WebGL/scalar-validity output as ground truth.
- This does not claim tone-mapped wrong-side ratios are promotion metrics.
- This does not claim intermediate SH visibility aggregate drift is final runtime leakage.
- This does not claim display-mapped StandardMaterial surface ratios are linear irradiance proof metrics; they remain diagnostic context only.

## Working prompt

Continue the LightProbeGridGPU refactor from the current worktree as authoritative. Find the next smallest slice that improves ownership shape, compactness, or leak evidence. Keep runtime free of CPU readback/proof helpers. Keep diagnostics/evals as raw facts, keep verdicts in proof gates, update this roadmap with every material finding, and verify with focused no-build checks only.

## Rejected adjacent visibility-moment rescue

Goal: prove whether a bounded GPU-resident adjacent visibility-moment lookup can eliminate the four `visibilityWeighting.noWrongSideEscape` exact-bin no-hit escapes without regressing directional suppression, correct bounce, compact proof ownership, runtime GPU residency, or residual-leak honesty.

Ideal state:

- `visibilityWeighting.noWrongSideEscape` is supported with `wrongSideEscapedCount = 0`;
- the four current 8px exact-bin no-hit misses are rescued by adjacent-bin coverage;
- `visibilityWeighting.directionalSuppression`, SH-risk, and correct-bounce gates remain supported;
- `sealedWall.preToneMaskedWrongSideResidualLeakRatio` remains independent and honest against the zero-leak oracle;
- runtime remains GPU-resident and diagnostics emit compact raw fallback facts only.

Preferred research candidate: conditional cross-bin fallback. Runtime should load the exact oct bin first; only when `hitConfidence` is zero should it sample the four cross-adjacent bins, compute the same Chebyshev visibility for adjacent hits, and choose the lowest computed visibility as the conservative replacement. If no adjacent hit exists, preserve current no-hit behavior. Use unconditional cross lookup only as an upper-bound comparison, and defer 3x3 lookup until cross fallback fails with evidence.

Acceptance requires closing `visibilityWeighting.noWrongSideEscape` without opening directional suppression, bounce, SH-risk, compactness, runtime-boundary, or residual-honesty checks. Rejection is also a valid outcome: if the candidate over-occludes, costs too much, bloats proof payloads, or leaves the gate open, keep it out of runtime and classify the remaining escapes as a known 8px octahedral visibility-moment exact-bin coverage limitation.

Adjacent-cross prototype result: rejected. Conditional-cross produced compact fallback facts (`adjacentFallbackActivationCount = 11`, `adjacentFallbackLoadCount = 44`, `adjacentFallbackRescueCount = 5`, `adjacentFallbackNoAdjacentHitCount = 6`) but did not close `visibilityWeighting.noWrongSideEscape`; `wrongSideEscapedCount` remained `4` and residual leak remained independently open at `0.942`. The unconditional-cross upper bound also left `wrongSideEscapedCount = 4` and opened directional suppression (`0.1838`) plus receiver-surface agreement (`0.2422`). The adjacent lookup was removed from runtime/mirror code; keep the gate open as a known 8px exact-bin visibility-moment limitation.

Do not reopen the same adjacent-cross fallback unless new evidence changes the failure class. The current evidence says adjacent hits exist, but borrowing them naively does not produce a correct visibility decision. That means the missing seam is not "sample one neighboring texel"; it is a stronger visibility representation or wall-aware classification policy.

Follow-up trim: the rejected adjacent-fallback evaluator and fallback activity counters were removed from the visibility study, proof facts, runner assertions, and proof-gate evidence. Keep only the adjacent-hit localization count because it explains the current failure class; do not keep failed-rescue payloads in the live proof interface.

## Promoted cross-bin bake dilation

The visibility-moment repack now samples the center, half-pixel cardinal taps, and one-pixel cardinal taps during the GPU bake. This keeps runtime sampling cost unchanged and remains GPU-resident while giving exact bins a bounded chance to capture nearby angular occluder coverage.

Focused Cornell proof result: `TEST PASSED`, 33 checks, proof summary remains `OPEN` with 14 supported / 2 open gates. The safe cross dilation does not close `visibilityWeighting.noWrongSideEscape`: `wrongSideEscapedCount = 4`, `weakCrushNoHitEscapeCount = 4`, adjacent-bin hit count `4`. It does improve the residual gate slightly: pre-tone masked wrong-side leak moves from `0.8126` to `0.8089`, and residual leak ratio moves from `0.942` to `0.9377`; correct bounce remains preserved.

Rejected stronger variant: one-pixel diagonal taps reduced `wrongSideEscapedCount` to `3` and residual to `0.9353`, but opened `receiverSurface.cpuRenderAgreement` and `shContribution.noBakedMixedColorRisk`. That is overreach, not a valid proof fix.

## Next serious gaps

1. Visibility representation: evaluate DDGI-style visibility quality as a representation problem. A resolution bump alone is rejected for this patch, but a future candidate may pair higher directional resolution with resolution-scaled moment/bias policy, gutters/borders, and explicit over-occlusion gates. Treat 8px as a measured limitation of the current visibility-depth representation, not as a magic constant to defend.
2. Probe classification/relocation: add a proof slice only if it can classify interior/exterior or invalid/occluding probes with compact facts. Unity APV and RTXGI both treat probe validity/classification as first-class leak controls.
3. Product API shape: keep the runtime interface small and GPU-resident. The upstream LightProbeVolume discussion points toward grid volumes and material/object irradiance, not scene-global mutable LightProbe state.
4. Bloat control: consolidate proof ownership before adding algorithms. If a diagnostic field is not consumed by a gate, artifact contract, or public example, remove it.

## SDD ultraplan alignment

Current truth: the proof package is open with 14 supported gates and 2 open gates. `visibilityWeighting.noWrongSideEscape` still reports `wrongSideEscapedCount = 4`; `sealedWall.preToneMaskedWrongSideResidualLeakRatio` remains `0.942` against the physical zero-leak oracle. The scalar/WebGL path is a leaky comparator, not truth. The current `8px` setting is angular octahedral visibility resolution, not screen pixels, and the evidence classifies it as exact-bin visibility coverage limitation with adjacent-bin hit evidence.

Earliest blocking gate: `visibilityWeighting.noWrongSideEscape`. Do not route around it with threshold changes, baseline storytelling, or proof-payload expansion. The next SDD slice must change the visibility representation or probe classification policy and prove that it does not over-occlude correct-side contribution.

| Lane | Intended goal | Promotion gate | Do not promote |
|------|---------------|----------------|----------------|
| Visibility representation | Replace exact-bin fragility with a visibility model that can represent wall-crossing occlusion | Fewer or zero wrong-side escapes with `visibilityWeighting.directionalSuppression`, SH-risk, and bounce gates still supported | Raw 16px bump, naive adjacent fallback, threshold tuning |
| Probe classification/relocation | Keep invalid, interior, exterior, or wall-crossing probes from contributing across sealed walls | Compact classification facts explain which probes are excluded or relocated and why | Brightness-derived validity, CPU-only proof helpers, scene-specific hacks |
| Bias/resolution coupling | Re-test resolution only with scaled moment/bias policy and gutters/borders | Resolution improves coverage without directional-suppression regression | Treating 8/12/16px as magic constants |
| Product API shape | Preserve a deep GPU-resident LightProbeGridGPU interface for grid-volume sampling | Runtime stays free of readback/proof helpers and exposes small sampling controls | Scene-global mutable LightProbe state as product target |
| Proof compactness | Keep diagnostics as raw facts and gates as verdict owners | Rejected-path fields stay absent by source invariant | Row dumps, per-probe arrays, duplicate gate math |

```mermaid
flowchart TD
	A["Current proof: 14 supported, 2 open"] --> B["Open gate: noWrongSideEscape = 4"]
	A --> C["Open gate: residual leak ratio = 0.942"]
	B --> D["8px exact oct-bin no-hit misses"]
	D --> E["Adjacent bins have hit evidence"]
	E --> F["Naive adjacent fallback rejected"]
	F --> G["Visibility representation SDD"]
	C --> H["Zero-leak oracle stays truth"]
	H --> G
	G --> I["Probe classification / relocation SDD"]
	I --> J["Promotion only if suppression, bounce, SH-risk, and compactness gates hold"]
```

## Phase roadmap

| Phase | Name | Slice | Exit condition |
|-------|------|-------|----------------|
| 57 | Visibility Representation SDD | Design and prototype a stronger visibility representation contract before changing resolution again | Candidate is either promoted by gates or rejected with compact evidence |
| 58 | Probe Classification/Relocation SDD | Add wall-aware probe classification/relocation evidence without CPU runtime leakage | Classification facts explain wrong-side exclusion/relocation and gates stay compact |
| 59 | Bias/Resolution Coupling | Re-run 8/10/12/16 only with resolution-scaled moment/bias policy and over-occlusion gates | Any resolution change improves escape evidence without directional regression |
| 60 | Product API Shape | Align public controls with GPU-resident grid-volume sampling and object/material irradiance direction | Runtime interface is small, documented, and not tied to leaky baseline semantics |
| 61 | Proof Compactness | Delete or guard stale diagnostic payloads after each rejected prototype | Source invariants keep rejected branches out of live proof facts |

## Latest eval findings

- 2026-06-02 focused smoke now passes after two correctness fixes: the atlas verifier imported the missing TSL `floor()` used by its synthetic coefficient writer, and `CubeTextureNode` now treats `builder.object?.isComputeNode` as compute context so explicit cubemap sampling does not pull `materialEnvRotation` from a null render scene/material. Because examples load `build/three.webgpu.js`, the same CubeTextureNode guard was mirrored there without running build.
- Latest Cornell smoke before the current gate cleanup: `TEST PASSED`, 33 checks. Proof summary was `OPEN` with 13 supported / 3 open gates: receiver-surface CPU/render delta `0.6014 > 0.15`, tone-mapped wrong-side improvement `-0.0025 < 0.05`, and masked wrong-side improvement `0.0004 < 0.05`.
- Visibility-weighting diagnostics now compare moment suppression against base visibility weights, not pre-kernel scalar weights, and use the same un-biased receiver position as runtime guarded visibility. This moved directional suppression from open to supported without changing proof thresholds.
- Latest leak promotion metric is still thin: pre-tone masked wrong-side improvement is `0.058` against the `>= 0.05` gate, with correct-bounce preservation healthy at `0.9974` and pre-tone masked correct-bounce preservation `1.0616`.
- Leak evidence artifacts now write compact `leak-proof-facts.json` next to `proof-summary.json`, so the raw sealed-wall baseline row and visibility-moment candidate row can be compared directly without inflating proof-gate summaries.
- Latest ground-truth framing: the scalar-validity baseline is not truth because it leaks too. Current pre-tone masked wrong-side leak is `0.8626` for baseline versus `0.8126` for visibility moments, so the candidate closes only `5.8%` of the baseline-to-zero gap and still leaves about `94.2%` of the baseline leak residual. This must stay visible in proof artifacts/gates.
- Receiver-surface Slice 2 found a real CPU diagnostic mirror bug: `LightProbeGridGPUShDiagnostics.js` used `visibilityAggregate.totalWeight / 0.0001` as a coefficient blend, while runtime uses `visibilityMass = totalWeight / baseWeight` and applies that mass after visibility SH irradiance evaluation. The diagnostic now mirrors the runtime mass path, and source invariants guard against reintroducing the stale `visibilityWeightFloor` formula.
- SH mixed-color Slice 3 found an over-broad proof predicate: the gate treated intermediate `visibilityWrongRatioMean` as equivalent to final runtime mixed-color risk. The gate now uses final `runtimeWrongRatioMean`; intermediate visibility wrong-ratio remains a raw diagnostic fact, not a promotion blocker.
- Refreshed eval after tightening showed SH runtime wrong-ratio is low (`0.0318 < 0.25`) while `wrongSideEscapedCount = 4`. That means the remaining signal is visibility escape evidence, not SH mixed-color risk, so the proof gates now separate `shContribution.noBakedMixedColorRisk` from `visibilityWeighting.noWrongSideEscape`.
- Latest refreshed proof: `TEST PASSED`, 33 checks, proof summary `OPEN` with 14 supported / 2 open gates. Open gates are `visibilityWeighting.noWrongSideEscape` (`wrongSideEscapedCount = 4`, expected `0`) and `sealedWall.preToneMaskedWrongSideResidualLeakRatio` (`0.942`, expected zero-leak oracle).
- Latest compact true-escape evidence: double-sided visibility-distance capture removed the `receiver-before-mean` subcase, but refreshed Cornell proof smoke still reports `wrongSideEscapedCount = 4`, now split as `receiverBeforeMeanEscapeCount = 0`, `highChebyshevEscapeCount = 0`, and `weakCrushEscapeCount = 4`, while visibility-bias and front-edge bypass counts remain `0`. All four weak-crush escapes are `weakCrushNoHitEscapeCount = 4`, with `weakCrushPartialHitEscapeCount = 0`, `weakCrushFullHitEscapeCount = 0`, and `weakCrushNearThresholdEscapeCount = 0`, so the open gate is owned by moment coverage misses rather than hit-confidence dilution, SH mixed-color drift, or fixture edge bypass.
- Final no-hit localization evidence: the open `visibilityWeighting.noWrongSideEscape` gate now carries `visibilityDepthResolution = 8`, `weakCrushNoHitCrossingCount = 4`, `weakCrushNoHitVisibilitySegmentHitCount = 4`, `weakCrushNoHitSurfaceSegmentHitCount = 4`, `weakCrushNoHitReceiverProbeDirectionMismatchCount = 0`, `weakCrushNoHitAdjacentHitCount = 4`, `weakCrushNoHitAllAdjacentNoHitCount = 0`, and `weakCrushNoHitDistinctOctBinCount = 4`. This classifies the remaining escapes as exact-oct-bin no-hit misses with adjacent-bin coverage, not culling/side capture, receiver/probe direction mismatch, visibility-bake absence, or fixture geometry bypass.
- Rejected runtime heuristic: treating any partial visibility hit as full Chebyshev ownership did not reduce the four escapes and slightly worsened rendered leak/correct-bounce ratios, so it was reverted.
- Receiver-surface agreement was tightened after audit: diagnostics now emit raw surface render wrong-ratio plus CPU surface runtime wrong-ratio max, while the proof gate derives `surfaceCpuRenderDelta` with max-to-max aggregation. Masked render ratios stay in leak-proof rows, not in the receiver-surface gate's evidence path.
- Latest receiver-surface evidence: display-space surface ratios remain high (`renderSurfaceWrongRatio = 0.8219`, `renderSurfaceCenterWrongRatio = 0.9314`) and sRGB unlit irradiance is display-skewed (`renderIrradianceCenterWrongRatio = 0.5882`), but the gate now compares linear unlit runtime irradiance against the CPU center mirror (`renderLinearIrradianceCenterWrongRatio = 0`, `centerRuntimeWrongRatioMax = 0.0635`, delta `0.0635 <= 0.15`). The previous open gate was a diagnostic mismatch: linear CPU evidence was being compared to display-mapped render ratios.
- Sealed-wall promotion gates now block only on the linear pre-tone masked leak metric plus correct-bounce preservation. Tone-mapped wrong-side improvements remain derivable from raw rows but no longer block proof promotion.
- Core runner projection-oracle assertions now use named local predicates for parity contract, compute candidate, adapter fallback, and atlas repack raw facts; source invariants guard those predicate seams instead of brittle inline assertion blobs.
- Visibility runner assertions now use named local predicates for moment readback facts, visibility-weighting facts, escape classification, SH contribution, receiver-surface agreement, and receiver-normal facts.
- Matrix runner assertions now use named local predicates for compact probe occupancy, sealed-wall leak-proof fixture facts, leak-proof row facts, and restoration facts.
- Runtime runner assertions now use named local predicates for bake coalescing, benchmark backend/memory/visibility-depth/timing facts, and compact color-sanity facts.
- Core runner runtime parity and projection profiling assertions now use named local predicates for raw parity facts, support facts, profiling selector facts, and compact timing facts.
- Proof-summary validation now uses named predicates for bounded gate count, unique/required gate ids, compact gate shape, required supported gates, and summary byte budget.
- Proof-validation density row checks now use named predicates for WebGPU/WebGL density reference, shadowless, crisp-shadow row facts, crisp-shadow reference comparison facts, damped quality-candidate fixture facts, and damped math-action facts; this also fixed a missing-comma assertion bug in the density damped row check and removed the lazy `snapshot, snapshot` crisp-shadow self-comparison.
- Proof-validation low-res comparison checks now use named predicates for shared probe intensity, band isolation, bounce preservation, and damped-vs-full-band red-bias/dark-tail comparison.
- Compact payload assertions now cover visibility-depth facts, visibility moment evidence, color sanity, artifact center signatures, projection fixture/fallback counts, and `getMetrics()` timing facts.
- Source invariants now guard against reintroducing raw RGB regions, timing sample/range payloads, profiling backend verdict/fallback arrays, runtime-parity phase timing/path label dumps, leak-proof restore metric dumps, nested leak-proof metric snapshots, sealed-wall derived gate metric payloads, sealed-wall row visibility-depth duplication, visibility-weighting diagnostic visibility-depth duplication, sealed-wall promotion metric mode echoes, leak-region center/surface-correct/masked-mode payloads, leak-proof top-level metric-mode prose, receiver-normal sample arrays/distance payloads/fallback reasons, visibility-weighting escape rows, internal escape-probe arrays, duplicate escape-summary reducers, duplicate receiver row totals/escape filter reducers, unused hit-confidence threshold/policy branches, visibility-weighting aggregate predicate/reader adapters, stale proof-era unavailable-mode labels, receiver quadrature-weight echoes, receiver-surface `runtimeWrongOverCorrect` naming, receiver-surface mutable sample counting, duplicate proof-gate runtime/projection/moment-readback/receiver-normal/directional-suppression/receiver-surface/SH-risk/sealed-wall predicates, proof-gate runtime identity echoes, visibility-weighting diagnostic-scope/label echoes and directional-suppression verdict echoes, color-bias objects/channel/value echoes, placeholder GPU-debug unavailable payloads, receiver quadrature sample descriptor metadata, receiver-surface render-agreement object wrappers, and duplicate receiver-surface fixture/rule echoes, visibility-weighting/receiver-surface/SH contribution nested summaries, SH contribution receiver-diagnostics wrapper reductions, SH math THREE parity support verdict echoes, artifact snapshot proof-role echoes, artifact snapshot derived bake-texel budget echoes, duplicate proof-validation density budget checks, repeated proof-validation absence predicates, repeated proof-validation artifact-pressure fact predicates, repeated proof-validation region fact checks, repeated proof-validation crisp direct-shadow control predicates, duplicate grounding-parity base setup and band-2 setup echoes, artifact snapshot anti-ringing policy/prose/path echoes, default direct-shadow-control snapshot echoes, direct-shadow-control mode echoes, default bake-shadow-disabled flag echoes, artifact probe-helper intensity echoes, artifact runtime/debug metric echoes, per-probe occupancy metadata, visibility-depth runtime metadata, divider-audit reason payloads, projection/atlas promotion/source/policy prose, projection parity marker-allowance/path-introduced echoes, projection parity promotion-evidence payloads, atlas-repack adapter-fallback policy echoes, duplicated projection fallback scenarios, SH math prose/sample/axis verdict payloads, atlas packing layout/readback arrays, runtime parity pass booleans/sample arrays, and old moment texture/sample details.
- The current evidence still points to payload leakage as the main refactor opportunity, not a runtime GPU residency leak.
- Rejected adjacent-fallback payloads were trimmed after the external research pass: `LightProbeGridGPUVisibilityWeightingStudy.js` now mirrors exact-bin visibility weighting again, `proof-gates` no longer carry `adjacentFallback*` evidence, and source invariants now guard against reintroducing those fields. The useful adjacent-bin evidence remains as localization, not as a failed rescue interface.

## Non-negotiables

- No build runs for this refactor stream.
- Use focused no-build checks: `node --check`, direct source invariant invocation, and `git diff --check`.
- Keep `examples/jsm/lighting/LightProbeGridGPU.js` free of CPU readback (`readRenderTargetPixels`, `readPixels`, `Data3DTexture`).
- Keep proof/readback/CPU mirror logic out of runtime.
- Do not add thin pass-through modules. Prefer local helpers when callers are harness-only.
- Delete legacy/prototype report payloads instead of preserving wrappers.
- Preserve public example imports and smoke harness method names unless a gate is intentionally tightened.

## Current shape

| File | Lines | Role | Status |
| --- | ---: | --- | --- |
| `examples/jsm/lighting/LightProbeGridGPU.js` | 1649 | Runtime facade | GPU-resident; no CPU readback matches; `getVisibilityDepthInfo()` now exposes compact availability/mode/byte facts only. |
| `examples/jsm/lighting/LightProbeGridGPUTestHarness.js` | 2584 | Browser proof/smoke harness | Main remaining monolith. Recent slices removed setter, fixture, rejection, profiling sample/range payload, runtime-parity phase timing/static-work/path-label dumps, leak-proof row/nested metric snapshot, leak-proof derived sealed-wall gate metrics, leak-proof row visibility-depth duplication, leak-proof promotion and restore metric dump, sealed-wall promotion metric mode echoes, leak-region center/surface-correct/masked-mode payloads, leak-proof top-level metric-mode prose, visibility-moment range/profile/runtime-info payload, compacted exported visibility-depth, timing, color-sanity, probe-occupancy, SH math, atlas packing, and runtime parity facts, runtime-smoke, profiler/runtime-parity/projection-oracle/artifact-pressure verdict payload, projection/atlas promotion/source/policy prose and unconsumed contract fields, projection parity marker-allowance/path-introduced/path-label echoes, projection parity promotion-evidence payloads, atlas-repack adapter-fallback policy echoes, duplicate projection fallback scenarios, projection adapter internal scenario labels/path echoes, projection adapter local decision verdicts, profiling backend mismatch verdict counts, profiling requested-backend selector echoes, profiling fallback reason counts, artifact snapshot prose/unused center RGB/chroma fields, artifact snapshot proof-role echoes, artifact snapshot derived bake-texel budget echoes, duplicate grounding-parity base setup and band-2 setup echoes, artifact anti-ringing policy/prose/path echoes, default direct-shadow-control snapshot echoes, direct-shadow-control mode echoes, default bake-shadow-disabled flag echoes, artifact probe-helper intensity echo, artifact runtime/debug metric echoes, projection fallback prose, receiver-normal verdict duplication, receiver-normal sample arrays/distance payloads/fallback reasons, and SH math THREE parity support verdict echoes. |
| `examples/jsm/lighting/LightProbeGridGPUVisibilityWeightingStudy.js` | 589 | CPU/proof visibility weighting study | Trimmed unconsumed row variance/hit-confidence summaries, unused hit-confidence threshold/policy branches, aggregate predicate/reader adapters, receiver quadrature-weight echoes, unused contribution ratios, duplicate escape-count families/reducers, duplicate receiver row totals/escape filter reducers, directional-suppression verdict/scope/receiver-label/policy-label payload, color-bias object/channel/value echoes, public per-probe/per-receiver receiver row dumps, runner-only contribution/visibilityMass summary fields, SH chroma-pressure helpers, exported visibility-depth runtime metadata, visibility-depth diagnostic duplication, stale proof-era unavailable-mode labels, placeholder GPU-debug unavailable payloads, aggregate escape row/reason payloads, internal escaped-probe arrays, internal divider-audit payload objects, and the `directionalSuppressionSupported` verdict echo; receiver probe and escape counters are now accumulated during receiver row analysis through `probeFacts`, public `receiverProbeFacts` remains compact, `escapeClassification` is derived from the same aggregate, and proof gates derive support from raw comparable receiver count plus wrong-minus-correct suppression. |
| `examples/jsm/lighting/LightProbeGridGPUShDiagnostics.js` | 90 | SH pressure diagnostics | SH mixed-color risk now emits proof-gate-consumed flat wrong-ratio and mixed-color row facts only; receiver contribution rows/aggregate snapshots stay internal, and the two-receiver aggregation no longer builds a receiverDiagnostics wrapper array. |
| `examples/jsm/lighting/LightProbeGridGPUReceiverDiagnostics.js` | 91 | Receiver/surface diagnostics | Surface CPU/render diagnostics now emit only proof-gate-consumed sample count, raw surface render wrong-ratio, and raw CPU surface runtime wrong-ratio max; masked render ratios and derived deltas stay out of the diagnostic, and nested summary, duplicate fixture/rule/receiver-label echoes, placeholder GPU-debug objects, exported quadrature helper, sample descriptor metadata, render-agreement object wrappers, mutable sample counting, old wrong-over-correct naming, and unused hit-confidence policy threading are gone. |
| `examples/jsm/lighting/LightProbeGridGPUExampleGUI.js` | 161 | Example controls | Stable. |
| `examples/jsm/lighting/lightprobegridgpu/LightProbeGridGPUProofReadback.js` | 285 | Proof-only readback adapter | Correct boundary: diagnostics may import, runtime must not. |
| `examples/jsm/lighting/lightprobegridgpu/LightProbeGridGPUConstants.js` | 60 | Shared constants | Intentionally small. |
| `examples/jsm/lighting/lightprobegridgpu/LightProbeGridGPUAtlas.js` | 159 | Atlas/probe addressing and repack | Cohesive. |
| `examples/jsm/lighting/lightprobegridgpu/LightProbeGridGPUCpuShMath.js` | 263 | Proof-only CPU SH math | Correct boundary. |
| `examples/jsm/lighting/lightprobegridgpu/LightProbeGridGPUProjection.js` | 242 | Projection material/node builders | Cohesive runtime helper. |
| `examples/jsm/lighting/lightprobegridgpu/LightProbeGridGPUVisibility.js` | 135 | Visibility material/load helpers | Cohesive runtime helper. |
| `examples/jsm/lighting/lightprobegridgpu/LightProbeGridGPUBake.js` | 132 | Bake state/result helpers | Cohesive runtime helper. |
| `test/e2e/lightprobegrid-gpu-artifacts.js` | 181 | Compact artifact contract | Healthy after earlier report deletion; proof summary and leak-proof baseline/candidate raw facts are written as compact single-line JSON, and the WebGL reference artifact keeps raw fields without prose boundary payload. |
| `test/e2e/lightprobegrid-gpu-image-metrics.js` | 174 | Screenshot artifact metrics | Artifact pressure now emits raw ratios/floors only. |
| `test/e2e/lightprobegrid-gpu-proof-validation.js` | 372 | Artifact proof assertions | Owns artifact pressure fact validation/thresholds, label-to-role interpretation, density budget checks, unweighted/hardware-filtered sampling checks, same-density-fixture checks, density reference/shadowless/crisp-shadow row/crisp-shadow comparison/damped fixture and damped math-action row checks, low-res shared-intensity/band-isolation/bounce/damped-comparison checks, derived bake-texel budget math, anti-ringing path/band checks, proof-role absence, anti-ringing policy absence, default direct-shadow-control absence, direct-shadow-control mode absence, default bake-shadow-disabled flag absence, probe-helper intensity absence, compact region fact checks, and runtime/debug metric absence through local helpers instead of trusting payload status or prose/path echoes; asserts compact artifact center/timing signatures, fixes the density damped row assertion comma bug, and avoids crisp-shadow self-comparison. |
| `test/e2e/lightprobegrid-gpu-proof-gates.js` | 486 | Proof gate derivation/assertions | Visibility moment, projection parity, directional suppression, and sealed-wall thresholds are data-driven; receiver-normal, visibility-weighting, receiver-surface, SH contribution, runtime parity, and sealed-wall improvement/preservation derivation now live here instead of the harness/study/diagnostic modules; runtime, projection, moment-readback, receiver-normal, directional-suppression, receiver-surface, SH-risk, sealed-wall, and proof-summary validation reuse named predicates, projection runtime parity, receiver-normal agreement, and receiver-surface CPU/render delta are derived from raw fact counts/ratios inside proof gates, sealed-wall proof facts now keep raw baseline/candidate leak rows while gate evaluation derives only blocking pre-tone leak improvement plus bounce-preservation metrics, tone-mapped sealed-wall wrong-side improvements are no longer derived as promotion math, proof-summary support/open counts are accumulated in one pass, visibility moment, directional suppression, receiver-surface, SH mixed-color risk, runtime readiness/texture/bounds, projection delta, receiver-normal availability/agreement, no-SH-risk, sealed-wall threshold pass states, bounded gate count, unique/required gate ids, compact gate shape, required supported gates, and summary byte budget are predicate-owned, supported gates omit remediation prose/evidence refs and actual/expected values from the compact proof summary, unused visibility/DDGI status payloads are gone, and unused runtime identity echo is gone. |
| `test/e2e/lightprobegrid-gpu-runner-*.js` | 806 | Smoke assertion runners | Mostly reasonable; core/matrix/visibility/runtime assertions now target compact raw contracts instead of local verdict payloads, projection/atlas promotion prose and unconsumed contract fields, projection parity marker-allowance/path-introduced echoes, projection parity promotion-evidence payloads, atlas-repack adapter-fallback policy echoes, SH math prose/sample/axis verdict payloads, SH math THREE parity support verdict echoes, atlas packing layout/readback arrays, runtime parity pass booleans/sample arrays/phase timing dumps/static-work echoes, profiling backend verdict/fallback arrays, profiling backend mismatch verdict counts, profiling fallback reason counts, leak-proof restore metric dumps, nested leak-proof metric snapshots, sealed-wall derived gate metric payloads, sealed-wall row visibility-depth duplication, visibility-weighting diagnostic visibility-depth duplication, leak-region center/surface-correct/masked-mode payloads, leak-proof top-level metric-mode prose, receiver-normal sample arrays/distance payloads/fallback reasons, visibility-weighting escape/per-receiver rows, visibility-weighting/receiver-surface/SH contribution nested summaries, placeholder GPU-debug unavailable payloads, per-probe occupancy metadata, projection fixture/fallback arrays, raw color regions, raw rows, timing sample/range payloads, visibility-depth runtime metadata, receiver-surface diagnostic-owned deltas, or directional-suppression verdict echoes; core projection/atlas/runtime-parity/profiling plus matrix/runtime/visibility absence assertions now share local field-absence helpers instead of repeating selector/verdict field checks inline, and core projection-oracle/parity/profiling, matrix leak-proof, runtime benchmark/color-sanity, and visibility raw-fact checks use named local predicates. |

Tracked LightProbeGridGPU feature/proof set: about 8,429 lines, excluding this plan and source-invariant guard file.

## Dependency rules

```text
Runtime
  LightProbeGridGPU.js
    -> lightprobegridgpu runtime helpers only
    -> no proof readback, no CPU SH math, no report code

Diagnostics / harness
  LightProbeGridGPUTestHarness.js
  LightProbeGridGPUVisibilityWeightingStudy.js
  LightProbeGridGPUShDiagnostics.js
  LightProbeGridGPUReceiverDiagnostics.js
    -> CPU/proof helpers allowed
    -> compact facts only; no exploratory report dumps

Reports / e2e
  test/e2e/lightprobegrid-gpu-*.js
    -> consume harness facts
    -> assert gate contracts, not raw lab payloads
```

## Completed cleanup themes

- Runtime helper ownership is now split by real rendering responsibility: constants, atlas, projection, visibility, bake state.
- Proof readback is isolated in `LightProbeGridGPUProofReadback.js`.
- CPU SH proof math is isolated in `LightProbeGridGPUCpuShMath.js`.
- Artifact/report output was reduced to compact proof facts instead of giant exploratory markdown/json payloads.
- Receiver and SH diagnostics were trimmed to consumed gate fields.
- Harness proof setup now shares `applyProofBakeSettings()`.
- Harness endpoint setters now share `setBakeParameter()`.
- Harness contract/unit/projection fixture setup is consolidated locally.
- Harness validation rejection checks share one local capture primitive.
- Compute projection profiling keeps warmup execution but no longer returns warmup, per-run sample arrays, min/average/p95/max timing ranges, nested backend arrays, backend-selection verdict booleans, backend mismatch verdict counts, requested-backend selector echoes, fallback reason arrays/counts, deterministic timer flags, diagnostic status/policy text, claim text, or median speedup summaries; it keeps raw fallback-run counts instead.
- Compute projection runtime parity now returns raw tolerance, coefficient, atlas-count, backend, and fallback facts; proof gates and runner assertions derive parity verdicts, and local pass booleans, atlas sample arrays, static-work echoes, path-label echoes, and phase timing dumps are gone.
- Projection parity candidate/fallback/atlas-repack oracles now return raw path, threshold, capability, count, and delta facts without proof-only status, per-fixture arrays, per-fixture sweep echoes, fallback scenario arrays, internal adapter scenario labels/path echoes, local adapter decision verdicts, or prose reason strings.
- Projection parity runtime and oracle contracts now keep only raw sweep/fallback/tolerance/count/delta facts plus the single contract path family; old `runtimeMarkersAllowed`, `runtimePathIntroduced`, and duplicate candidate/adapter path-label echoes are gone, and source invariants prove guarded runtime markers directly from runtime implementation evidence instead of trusting harness allowance fields.
- Atlas repack oracle no longer echoes `adapterFallbackEvidenceRequired`; adapter fallback evidence is owned by the adapter fallback oracle, while atlas repack keeps only tolerance and max-readback-delta facts.
- Projection and atlas diagnostics no longer return unconsumed promotion-effect, candidate-planning/public-API policy flags, required-capability, required-gate prose, required parity source lists, checked-layer, coefficient-write count, required-flag, fixture-list, or open-evidence narrative payloads.
- Projection adapter fallback diagnostics now keep one supported runtime scenario plus the two fallback capability scenarios; the duplicated promoted-supported candidate row was deleted.
- Artifact pressure metrics now return raw black-tail/luminance/contrast facts; proof validation owns pressure/bounded thresholds.
- Artifact snapshot rows now keep structured role/policy facts without prose `referenceBoundary` or `action` payload.
- Grounding parity artifact snapshots no longer echo `proofRole`; proof validation owns label-to-role interpretation for those rows.
- Grounding parity artifact snapshots no longer echo derived bake-texel budgets; proof validation derives cubemap work from resolution and cubemap size.
- Grounding parity snapshot setup now centralizes the shared band-2 intensity instead of repeating the same constant in every frozen row.
- Grounding parity snapshot setup now has shared low-resolution and density base rows so per-case entries only show the values that actually vary.
- Proof validation now uses one local density-budget helper for repeated WebGPU/WebGL-like 6^3 / 32px checks.
- Proof validation now uses one local absence helper for compact metric, timing, and artifact-signature payload checks.
- Proof validation now uses one local artifact-pressure fact helper for both grounding parity snapshots and WebGL reference artifacts.
- Proof validation now uses one local region fact helper for both grounding parity snapshots and WebGL reference artifacts; grounding snapshots opt into black-tail/cell-edge checks while the WebGL reference keeps the smaller shared region contract.
- Proof validation now uses one local crisp direct-shadow control helper for both per-row artifact validation and cross-row density comparison.
- Core smoke assertions now use the local field-absence helper for projection contract/oracle, SH math, atlas packing, runtime parity, and profiling timing compactness checks instead of repeating long `field === undefined` chains.
- Matrix and runtime smoke assertions now use local field-absence helpers for probe occupancy, leak-proof row/restoration, benchmark visibility/timing, and color-sanity compactness checks.
- Artifact snapshot anti-ringing policy echoes were removed entirely; proof validation now derives stress/control/quality meaning from labels, SH band intensities, and sampling facts instead of persisted policy/path prose.
- Artifact snapshot direct-shadow control now emits only custom shadow override values; default direct-shadow-map settings and custom-mode prose stay implicit, and proof validation asserts their absence.
- Artifact snapshots now emit `shadowsDisabledDuringBake` only for the shadowless proof row; default bake-shadow-enabled state stays implicit and proof validation asserts its absence for the crisp-shadow control row.
- Artifact snapshots no longer echo probe-helper intensity; proof validation asserts that helper-only visualization intensity stays out of proof artifacts.
- Artifact snapshot metrics now use a compact snapshot-specific metric shape; runtime/debug facts such as memory, visibility-depth, identity, texture, bounds, and probe-helper state stay out of artifact rows.
- Artifact center signatures now expose only the consumed luminance fact; unused RGB/chroma fields were deleted.
- Leak-proof rows now share top-level proof settings, sampling, and metric modes instead of repeating frozen fixture controls or nested metric snapshots per row; restoration evidence now returns only lighting mode, leak-reduction mode, and fixture visibility instead of a full `getMetrics()` dump.
- Probe occupancy diagnostics now return counts and a mesh-hit count only; per-probe indices, positions, and mesh lists remain local to the example's validity upload path.
- Visibility weighting summaries no longer carry unused variance, hit-confidence, min/max visibility-mass, mirrored correct-side contribution ratios, or runner-only base/visible/visibilityMass contribution means.
- Visibility aggregate evaluation now owns the single SH readback path directly; dead predicate and coefficient-reader adapters were deleted because the only callers aggregate all rows with the default probe coefficient reader.
- Visibility weighting diagnostics now expose aggregate receiver probe counters instead of public per-probe weighting rows or per-receiver `left`/`right` payloads; aggregate escape facts stay in `escapeClassification`.
- Visibility-study receiver probe counters are now accumulated in the receiver-analysis pass via `probeFacts`; the old second pass over `receiver.rows` is guarded against by source invariants.
- Visibility-study escape counters now share the same `probeFacts` aggregate; the old per-receiver `escapeSummary` object and combiner are gone without adding escape fields to public `receiverProbeFacts`.
- Proof validation now uses `hasUnweightedSampling()` for repeated density/reference sampling checks instead of re-spelling weighted-sampling raw field comparisons inline.
- Proof validation now uses `hasHardwareFilteredSampling()` where density reference, crisp-shadow, and damped rows must prove both manual sampling is off and weighted sampling is off.
- Proof validation now uses density-specific helpers for the shared WebGPU/WebGL 6^3 / 32px budget and same-fixture checks, so density reference/damped/shadow rows prove fixture equivalence through named predicates instead of repeated inline field chains.
- Proof validation now splits crisp-shadow row facts from crisp-shadow cross-row comparison facts, so the per-row assertion no longer proves itself by comparing the snapshot to itself.
- Compact proof-summary gates now include `actual`/`expected`, remediation `reason`, and `evidenceRef` only for OPEN gates; SUPPORTED gates keep id/subject/metric/status only.
- `proof-summary.json` now writes compact single-line JSON instead of pretty-printing the already compact proof summary.
- Visibility weighting compact visibility-depth fallback now uses the neutral `unavailable` mode instead of the stale proof-era `unavailable-proof-6-runtime-removed` label.
- Visibility divider segment checks now return the consumed boolean intersection fact only; point/distance/reason audit payload objects were deleted.
- Visibility-depth facts exported by metrics, benchmarks, leak rows, and visibility-weighting diagnostics now stay to `available`/`mode`/`bytes`; private readback dimensions stay local to the harness and runtime.
- Runtime `getVisibilityDepthInfo()` now emits only `available`/`mode`/`bytes`; placeholder samples, stats, texture dimensions, moment count, encoding, and channel-label report fields were removed.
- Visibility moment inspection reports compact availability/mode/readback counters only; raw samples, range/profile payload, runtime-info metadata, texture metadata, channel labels, and deferred sweep-plan narrative are gone.
- Visibility-weighting diagnostics no longer duplicate compact visibility-depth facts; moment-readback proof remains owned by the dedicated visibility moment inspection and proof gates.
- Runtime smoke diagnostics now keep benchmark, bake coalescing, and leak-mode comparison payloads to asserted fields only.
- `getMetrics()` timing facts now expose only total bake time and timing source; detailed phase timing stays in benchmark-specific diagnostics.
- Color sanity diagnostics now return wall dominance ratios and center energy instead of raw left/right/center RGB regions.
- Visibility escape classification now keeps only aggregate escape counts, instead of public row/reason payloads, internal escaped-probe arrays, unused hit-confidence threshold escape branches, or duplicated per-receiver count families.
- Visibility escape summary now combines receiver escape facts in one reducer instead of running separate receiver reducers for each count.
- Visibility receiver analysis now derives totals and escape counters in one row pass instead of stacking `wrongSideRows`, `escapedRows`, reason filters, relation-key sum helpers, and separate base/visible sum reducers.
- Receiver-normal diagnostics now return raw availability and receiver/shader-normal count facts; the proof gate derives the front-face/shader agreement verdict, and internal shader-normal capture no longer creates public-style distance/convention payload fields or fallback reason prose.
- Visibility-weighting diagnostics now return flat fixture-mode, wrong-minus-correct suppression, and escape facts without nested summary, duplicate diagnostic-scope payloads, or `directionalSuppressionSupported` verdict echoes; the proof gate owns the directional suppression verdict.
- Receiver-surface diagnostics now return only sample count, raw CPU surface runtime wrong-ratio max, and raw render surface wrong-ratio; parent fixture mode supplies sealed-wall context, the Gauss-Legendre rule stays implicit in code plus runner sample-count assertions, quadrature sample descriptors keep only local position/weight inside receiver diagnostics instead of echoing quadrature weight through analyzed receiver objects, the placeholder GPU-debug unavailable diagnostic was deleted, and the proof gate owns the CPU/render agreement delta and verdict.
- Receiver-surface quadrature now derives `sampleCount` from `sampleDescriptors.length` instead of mutating a loop counter.
- Receiver-surface render agreement now emits raw max-to-max comparison inputs instead of diagnostic-owned candidate deltas.
- Receiver-surface render agreement now compares surface CPU quadrature only with surface render capture; masked render ratios remain leak-proof-row evidence and cannot lower or alter the surface agreement gate.
- Receiver-surface CPU/render agreement now compares render surface wrong-ratio max against CPU surface runtime wrong-ratio max; the old “pick the closer mean-or-max delta” diagnostic path is gone.
- Receiver-surface proof gating now derives `surfaceCpuRenderDelta` once, passes that derived fact into the receiver-surface predicate, and uses the same value as the gate actual; source invariants guard that single-owner derivation path.
- Sealed-wall proof gates no longer treat tone-mapped wrong-side improvement metrics as promotion blockers and no longer derive those unused improvement values; raw baseline/candidate rows still carry the underlying tone-mapped fields, while the blocking improvement gate uses `preToneMaskedWrongSideImprovement`.
- Receiver-surface CPU aggregation now uses the same `runtimeWrongRatio` language as SH contribution diagnostics; the old `runtimeWrongOverCorrect` name was deleted as color-bias report residue.
- SH contribution diagnostics now return only flat proof-gate-consumed mixed-color row count plus visibility/runtime wrong-ratio facts; runner-only scalar, inverted-normal, chroma-pressure, nested summary payloads, receiver contribution row echoes, color-bias objects/channel/value echoes, and aggregate color-bias snapshots were deleted.
- SH contribution two-receiver aggregation now uses direct left/right diagnostic facts instead of a temporary `receiverDiagnostics` wrapper array plus repeated reductions.
- SH math diagnostics now return constant-radiance max delta, directional axis deltas, THREE parity availability, and THREE parity delta only; prose formulas, sample arrays, expected color echoes, support verdict echoes, and local axis verdict booleans were deleted.
- Atlas packing diagnostics now return counts, mismatch counters, orientation probe indices, validity delta, and max readback delta; full coefficient layout, address/readback arrays, expected/actual pixel echoes, formula strings, and oracle path prose were deleted.
- Placeholder GPU-debug diagnostics were deleted after their unsupported/unavailable payload stopped feeding proof gates; runner assertions now guard that the payload stays absent.
- Visibility moment inspection now returns raw availability/mode/readback counters; the proof gate derives moment-backed support from bytes plus finite/hit readback evidence, not leaked texture metadata.
- Runtime, projection delta, visibility moment, receiver-normal, directional-suppression, receiver-surface, SH mixed-color, and sealed-wall proof gates now derive pass states from named predicates instead of duplicating status/readback/agreement/tolerance/risk/threshold conditions inside gate objects.
- Visibility moment readback, directional suppression, receiver-surface agreement, and baked SH mixed-color risk now use named proof-gate predicates instead of inline pass-condition locals.
- Runtime readiness/texture/bounds and projection coefficient/atlas delta gates now also use named proof-gate predicates instead of inline comparisons.
- Receiver-normal availability/agreement and no-baked-SH-risk pass states now also use proof-gate predicates instead of inline boolean composition.
- The unused visibility status wrapper is gone; moment-backed visibility validation now uses `isMomentBackedVisibility()` directly and source invariants guard against reintroducing `visibilityLabel`, `visibilityStatus`, or `ddgiStatus` payloads.
- Sealed-wall threshold pass states now use the proof-gate predicate path instead of inline `actual >= threshold` composition inside the gate loop.
- Projection runtime parity and receiver-normal proof facts now stay raw: proof facts carry backend/delta/count evidence, while proof gates derive runtime parity and normal agreement via named predicates.
- Sealed-wall proof facts now carry raw baseline/candidate leak-row metrics; proof gate evaluation derives wrong-side improvement and correct-bounce preservation metrics locally.
- Compact proof facts no longer carry `isLightProbeGrid`; runtime packaging identity is guarded by source invariants, while proof gates consume only status, texture, and bounds facts.
- Leak proof facts now return raw sealed-wall rows only; proof gates derive sealed-wall improvement/preservation metrics and own support/promotion verdicts, while nested/top-level metric mode prose, row-level visibility-depth duplication, and unconsumed center/surface-correct/masked-mode leak-region payloads stay absent.
- Grounding parity artifacts now persist `leak-proof-facts.json` as compact raw leak evidence: fixture/settings/sampling plus the two sealed-wall rows only, with finite raw leak and bounce metrics validated before writing.

## Current hotspots

1. **Wrong-side visibility escape** — refreshed eval reports `wrongSideEscapedCount = 4` with no visibility-bias or front-edge bypass subcounts, so these are true sealed-wall moment visibility escapes.
2. **Residual leak to ground truth** — refreshed eval reports residual leak ratio `0.942`; candidate improves versus baseline but remains far from the sealed-wall zero-leak oracle.

## Roadmap: finite remaining slices

This roadmap is deliberately capped. We are no longer doing generic payload cleanup. Every remaining task must close one of the current open proof gates or produce the final proof package.

### Current proof status

- `runtime.ready`, projection parity, atlas parity, visibility readback, receiver-normal agreement, directional suppression, SH mixed-color risk, baseline leak improvement, and correct-bounce preservation are supported.
- `visibilityWeighting.noWrongSideEscape` is open: `wrongSideEscapedCount = 4`, with `visibilityBypassEscapeCount = 0` and `frontEdgeBypassEscapeCount = 0`.
- The four wrong-side escapes are now classified as `receiverBeforeMeanEscapeCount = 0`, `highChebyshevEscapeCount = 0`, `weakCrushEscapeCount = 4`, and `weakCrushNoHitEscapeCount = 4`.
- `receiverSurface.cpuRenderAgreement` is supported after the gate stopped comparing linear CPU SH evidence to display-mapped standard-material surface ratios.
- Receiver-surface raw evidence remains useful diagnostic context: display-space surface ratios are high (`renderSurfaceWrongRatio = 0.8219`, `renderSurfaceCenterWrongRatio = 0.9314`), sRGB unlit irradiance is also display-skewed (`renderIrradianceCenterWrongRatio = 0.5882`), while the linear unlit irradiance center comparison agrees with the CPU center mirror within tolerance (`renderLinearIrradianceCenterWrongRatio = 0`, `centerRuntimeWrongRatioMax = 0.0635`, delta `0.0635 <= 0.15`).
- `sealedWall.preToneMaskedWrongSideResidualLeakRatio` is open: `0.942` against the physical zero-leak oracle.

### Slice 40: classify and attack true wrong-side visibility escapes

Target: `examples/jsm/lighting/LightProbeGridGPU.js`, `examples/jsm/lighting/LightProbeGridGPUVisibilityWeightingStudy.js`, `test/e2e/lightprobegrid-gpu-proof-gates.js`

Goal:

- explain the four remaining wrong-side escapes with compact reason counts;
- fix the runtime/diagnostic visibility logic if the cause is a real algorithm bug;
- otherwise classify why visibility moments alone cannot fully infer a sealed wall from the available runtime data.

Acceptance:

- `visibilityWeighting.noWrongSideEscape` becomes supported, or the gate remains open with source-backed evidence that the residual escape is an expected limitation rather than hidden proof drift;
- no row dumps, per-probe arrays, or narrative payloads are added;
- runtime stays GPU-resident and proof logic stays outside runtime.

Progress:

- Visibility distance capture is now double-sided so moment evidence does not depend on mesh front-face orientation.
- The double-sided pass removed the receiver-before-mean subcase, but all four remaining escapes are still weak-crush/weighting escapes.
- A more aggressive partial-hit Chebyshev heuristic was tested and reverted because it did not improve escape evidence or leak metrics.
- Compact follow-up evidence showed the four weak-crush escapes are no-hit moment coverage misses, not partial-hit dilution or near-threshold weighting.
- Angular-resolution sweep was tested and rejected as a clean fix: 10px preserved gate shape but did not improve the residual leak metric, while 12px/16px improved residual leak (`0.9274`/`0.908`) but opened `visibilityWeighting.directionalSuppression`, so the runtime keeps the original 8px visibility-depth resolution for this patch.

### Slice 41: receiver-surface gate decision

Target: `examples/jsm/lighting/LightProbeGridGPUReceiverDiagnostics.js`, `examples/jsm/lighting/LightProbeGridGPUShDiagnostics.js`, `test/e2e/lightprobegrid-gpu-proof-gates.js`

Goal:

- close the receiver-surface decision by comparing CPU SH evidence to linear unlit runtime irradiance rather than display-mapped standard-material surface ratios.

Acceptance:

- `receiverSurface.cpuRenderAgreement` reaches `<= 0.15`; display-space surface ratios stay as diagnostic context only;
- leak-proof masked render metrics are not reused to soften this gate;
- no new threshold is introduced just to make the current value pass.

Progress:

- Completed: refreshed proof now supports receiver-surface CPU/render agreement using linear unlit irradiance center evidence (`0.0635 <= 0.15`).
- Display-space standard-material and sRGB ratios remain high but are no longer used as the linear CPU/render agreement metric.

### Slice 42: final proof package

Target: `lightprobegrid-gpu-refactor-plan.md`, `openspec/changes/lightprobegridgpu-research-proof-evals/proof-ledger.md`, `openspec/changes/lightprobegridgpu-research-proof-evals/tasks.md`

Goal:

- publish the final bounded claim exactly as proven: GPU-resident visibility moments improve sealed-wall pre-tone masked leak by about `5.8%` versus a leaky scalar-validity baseline, preserve correct bounce, and still leave `0.942` residual leak against the zero-leak oracle.

Acceptance:

- final notes list supported gates, open diagnostics, and non-claims;
- focused no-build checks pass;
- refreshed proof artifacts match the roadmap;
- stop here unless a reviewer asks for a specific proof correction.

### Explicitly out of scope

- broad `LightProbeGridGPU` decomposition;
- full DDGI/global-illumination rewrite;
- making residual leak equal zero in this patch;
- treating scalar/WebGL baseline as ground truth;
- adding more eval payloads unless a proof gate consumes the raw fact.

## Verification commands

Use the narrowest applicable set per slice:

```bash
node --check examples/jsm/lighting/LightProbeGridGPUTestHarness.js
node --check examples/jsm/lighting/LightProbeGridGPUVisibilityWeightingStudy.js
node --check test/e2e/lightprobegrid-gpu-runner-core-assertions.js
node --check test/e2e/lightprobegrid-gpu-runner-visibility-assertions.js
node --check test/e2e/lightprobegrid-gpu-proof-gates.js
node --check test/e2e/lightprobegrid-gpu-source-invariants.js
node --input-type=module -e "import { checkSmokeSourceInvariants } from './test/e2e/lightprobegrid-gpu-source-invariants.js'; import { smokeHarnesses } from './test/e2e/lightprobegrid-gpu-smoke-config.js'; await checkSmokeSourceInvariants('webgpu_lightprobes_cornell', smokeHarnesses.webgpu_lightprobes_cornell);"
git diff --check
```

Do not run `npm run build` for this cleanup stream.

## Completion evidence

Current focused evidence supports the finite proof-package goal:

- runtime remains GPU-resident with no CPU readback matches in `LightProbeGridGPU.js`;
- latest Cornell WebGPU smoke passed 33 checks after the receiver-surface linear-irradiance gate fix; proof summary remains `OPEN` with 14 supported / 2 open gates;
- atlas packing verifier reports `maxReadbackDelta = 0.0005` against the `< 0.008` gate;
- compute projection runtime parity selects `compute-probe-reduction` with `computeFallbackReason = null`, `coefficientMaxDelta = 0`, and `atlasMaxDelta = 0`;
- diagnostics/harness no longer carry the targeted verdict, proofBoundary, status, referenceBoundary, or exploratory prose payloads;
- remaining files keep clear ownership without thin-file over-splitting;
- compact proof gates cover the default smoke proof behavior with a 16-gate budget and derive visibility support from compact readback facts; tone-mapped sealed-wall leak improvements are no longer promotion blockers;
- source-level receiver-surface and SH-risk predicate fixes are verified with no-build checks and refreshed runtime proof artifacts; the final PR claim explicitly lists the two open gates;
- source invariants, runner assertions, OpenSpec tasks, and this roadmap match the current code shape.
